import { createTheme } from '@mui/material/styles';
import primaryFont from '@/theme/fonts';

type SizeObject = {
  sm: number;
  md: number;
  lg: number;
};

export function pxToRem(value: number) {
  return `${value / 16}rem`;
}

export function responsiveFontSizes({ sm, md, lg }: SizeObject) {
  return {
    '@media (min-width:600px)': {
      fontSize: pxToRem(sm),
    },
    '@media (min-width:900px)': {
      fontSize: pxToRem(md),
    },
    '@media (min-width:1200px)': {
      fontSize: pxToRem(lg),
    },
  };
}

const theme = createTheme({
  palette: {
    primary: {
      main: '#FFFFFF',
    },
    secondary: {
      main: '#EA6303',
    },
    background: {
      default: '#181818',
    },

    text: {
      primary: '#E9E9E9',
      secondary: '#878787',
    },
  },

  typography: {
    fontWeightRegular: 400,
    fontWeightMedium: 500,
    fontWeightBold: 600,
    fontFamily: primaryFont.style.fontFamily,

    h1: {
      fontWeight: 600,
      fontSize: pxToRem(24),
      ...responsiveFontSizes({ sm: 42, md: 48, lg: 56 }),
    },
    h2: {
      fontWeight: 600,
      fontSize: pxToRem(24),
      ...responsiveFontSizes({ sm: 48, md: 48, lg: 48 }),
    },
    h3: {
      fontWeight: 600,
      fontSize: pxToRem(24),
      ...responsiveFontSizes({ sm: 24, md: 28, lg: 32 }),
    },
    h4: {
      fontWeight: 600,
      fontSize: 24,
    },
    h5: {
      fontWeight: 600,
      fontSize: 16,
      ...responsiveFontSizes({ sm: 24, md: 24, lg: 24 }),
    },
    subtitle1: {
      fontWeight: 400,
      fontSize: pxToRem(14),
      ...responsiveFontSizes({ sm: 18, md: 18, lg: 20 }),
    },
    subtitle2: {
      fontSize: 14,
      fontWeight: 400,
      ...responsiveFontSizes({ sm: 18, md: 18, lg: 18 }),
    },
    body1: {
      fontSize: 14,
      fontWeight: 400,
      ...responsiveFontSizes({ sm: 16, md: 16, lg: 16 }),
    },
    body2: {
      fontSize: 14,
      fontWeight: 400,
    },
  },

  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 900,
      lg: 1200,
      xl: 1448,
    },
  },

  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          background: '#181818',
        },
      },
    },

    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: '10px',
          background: '#181818',
          boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
          '@media (min-width: 600px)': {
            borderRadius: '20px',
          },
        },
      },
    },

    MuiIconButton: {
      defaultProps: {
        disableRipple: true,
        disableFocusRipple: true,
      },
    },

    MuiButton: {
      defaultProps: {
        disableRipple: true,
        disableFocusRipple: true,
      },
      styleOverrides: {
        root: {
          '&.Mui-disabled': {
            backgroundColor: '#181818',
            color: '#E9E9E9',
            border: '1px solid #E9E9E9',
          },
        },
      },
      variants: [
        {
          props: { size: 'small' },
          style: {
            height: '40px',
            fontSize: '16px',
            lineHeight: '20px',
            alignItems: 'center',
          },
        },
        {
          props: { size: 'medium' },
          style: {
            height: '58px',
            borderRadius: '10px',
            fontSize: '24px',
            lineHeight: '28px',
          },
        },
        {
          props: { variant: 'outlined' },
          style: {
            textTransform: 'none',
            backgroundColor: '#181818',
            color: '#E9E9E9',
            fontWeight: 400,
            transition: 'background-color 0.3s ease',
            '&:hover': {
              backgroundColor: '#181818',
              boxShadow:
                '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212, 0px 0px 10px 0px #EA6303',
            },
            '&:active': {
              backgroundColor: '#EA6303',
            },
          },
        },
      ],
    },
  },
});

export default theme;
