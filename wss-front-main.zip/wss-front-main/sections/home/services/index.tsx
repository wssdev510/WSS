import React from 'react';
import Container from '@mui/material/Container';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import CardContent from '@mui/material/CardContent';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import Image from 'next/image';
import { useTheme } from '@mui/material/styles';
import { Element } from 'react-scroll';
import useMediaQuery from '@mui/material/useMediaQuery';
import {
  StackBorder,
  IconButtonStyled,
  GridWrapper,
  CardStyled,
  CardActionsStyled,
} from '@/sections/home/services/styles';

import { Swiper, SwiperSlide } from 'swiper/react';
import RouterLink from '@/components/routerLink';

const services = [
  {
    title: 'Телохранитель',
    body: 'Предотвращение угроз и обеспечение личной безопасности и конфиденциальности',
    img: '/assets/services/bodyguard.png',
    href: '/bodyguard',
  },
  {
    title: 'Сопровождение',
    body: 'Обеспечение безопасности во время передвижения',
    img: '/assets/services/accompaniment.png',
    href: '/accompaniment',
  },
  {
    title: 'Охрана мероприятий',
    body: 'Защита от потенциальных угроз при массовом скоплении людей',
    img: '/assets/services/event-security.png',
    href: '/event-security',
  },
  {
    title: 'Охрана объектов',
    body: 'Организация комплекса мер по защите вверенного имущества и объекта',
    img: '/assets/services/object-security.png',
    href: '/object-security',
  },
  {
    title: 'Решение конфликтов',
    body: 'Профессиональная поддержка в разрешении споров',
    img: '/assets/services/conflict-resolution.png',
    href: '/conflict-resolution',
  },
  {
    title: 'Кадровый подбор',
    body: 'Подбор высококвалифицированного личного персонала',
    img: '/assets/services/personnel-selection.png',
    href: '/personnel-selection',
  },
  {
    title: 'Детективные услуги',
    body: 'Сбор и анализ информации, расследование',
    img: '/assets/services/detective.png',
    href: '/detective',
  },
  {
    title: (
      <>
        Монтаж охранных систем <br /> и видеонаблюдения
      </>
    ),
    body: 'Комплексное техническое оснащение объектов',
    img: '/assets/services/videosystem.png',
    href: '/videosystem',
  },
];

function ServicesSection() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Element name="services">
      <Container maxWidth="xl" disableGutters={isMobile}>
        <Stack alignItems="center" mt={{ xs: 10, sm: 5 }} mb={{ xs: 5.5, sm: 10 }}>
          <Typography variant="h1" component="h2">
            Услуги
          </Typography>
        </Stack>

        <Box mt={{ xs: 5, sm: 0 }} pb={{ xs: 3.5, sm: 0 }}>
          <Box sx={{ display: { xs: 'flex', sm: 'none' } }}>
            <Swiper slidesPerView={'auto'} spaceBetween={14}>
              {services.map((value, key) => (
                <SwiperSlide key={key} style={{ width: 'auto' }}>
                  <CardStyled>
                    <CardContent>
                      <StackBorder mt={1} alignItems="center" justifyContent="center">
                        <Image quality={100} src={value.img} width={102} height={102} alt="image" />
                      </StackBorder>

                      <Stack alignItems="center" justifyContent="center">
                        <Typography
                          variant="subtitle1"
                          fontWeight={600}
                          mt={1}
                          mb={1}
                          sx={{ fontSize: 14, textAlign: 'center', whiteSpace: 'nowrap' }}
                        >
                          {value.title}
                        </Typography>

                        <Typography
                          variant="body1"
                          color="#878787"
                          sx={{
                            textAlign: 'center',
                            maxWidth: 240,
                            lineHeight: '116.667%',
                            fontSize: 12,
                          }}
                        >
                          {value.body}
                        </Typography>
                      </Stack>
                    </CardContent>
                    <CardActionsStyled>
                      <IconButtonStyled component={RouterLink} href={value.href}>
                        <ExpandLessIcon color="primary" />
                      </IconButtonStyled>
                    </CardActionsStyled>
                  </CardStyled>
                </SwiperSlide>
              ))}
            </Swiper>
          </Box>
          {!isMobile && (
            <GridWrapper
              container
              spacing={{ xs: 2, sm: 5 }}
              justifyContent="flex-start"
              sx={{ display: { xs: 'none', sm: 'flex' } }}
            >
              {services.map((value, key) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={key}>
                  <CardStyled>
                    <CardContent>
                      <StackBorder mt={1} alignItems="center" justifyContent="center">
                        <Image quality={100} src={value.img} width={146} height={146} alt="image" />
                      </StackBorder>

                      <Stack alignItems="center" justifyContent="center">
                        <Typography
                          variant="subtitle1"
                          fontWeight={600}
                          mt={2.5}
                          mb={3}
                          sx={{ textAlign: 'center', lineHeight: '130%' }}
                        >
                          {value.title}
                        </Typography>

                        <Typography
                          variant="body1"
                          color="#878787"
                          sx={{
                            textAlign: 'center',
                            maxWidth: 240,
                            lineHeight: '125%',
                          }}
                        >
                          {value.body}
                        </Typography>
                      </Stack>
                    </CardContent>
                    <CardActionsStyled>
                      <IconButtonStyled component={RouterLink} href={value.href}>
                        <ExpandLessIcon color="primary" />
                      </IconButtonStyled>
                    </CardActionsStyled>
                  </CardStyled>
                </Grid>
              ))}
            </GridWrapper>
          )}
        </Box>
      </Container>
    </Element>
  );
}

export default ServicesSection;
