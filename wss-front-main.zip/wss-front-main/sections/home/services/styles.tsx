import React from 'react';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import { styled } from '@mui/material/styles';
const StackBorder = styled(Stack)(({ theme }) => ({
  width: '100%',
  height: 146,
  borderRadius: '20px',
  [theme.breakpoints.down('sm')]: {
    height: 102,
  },
}));

const IconButtonStyled = styled(IconButton)<{ component?: React.ElementType; href: string }>(
  ({ theme }) => ({
    width: 60,
    height: 60,
    marginBottom: '20px',
    boxShadow: '6px 6px 12px 0px #1E1E1E, -6px -6px 12px 0px #262626',
    border: '1px solid rgba(234, 99, 3, 0.5)',
    backgroundColor: '#181818',
    transition: 'background-color 0.3s ease',
    '&:hover': {
      border: '1px solid #EA6303',
      backgroundColor: '#181818',
      boxShadow: '6px 6px 12px 0px #1E1E1E, -6px -6px 12px 0px #262626, 0px 0px 10px 0px #EA6303',
    },
    '&:active': {
      backgroundColor: '#EA6303',
    },
    [theme.breakpoints.down('sm')]: {
      marginBottom: 0,
      width: 30,
      height: 30,
    },
  })
);

const GridWrapper = styled(Grid)(({ theme }) => ({
  '&::-webkit-scrollbar': {
    display: 'none',
  },
  msOverflowStyle: 'none',
  scrollbarWidth: 'none',

  [theme.breakpoints.down('sm')]: {
    flexWrap: 'nowrap',
    overflowX: 'scroll',
  },
}));

const CardStyled = styled(Card)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  height: '446px',
  '&:hover': {
    boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212, 0px 0px 4px 4px #EA6303',
  },
  [theme.breakpoints.down('sm')]: {
    maxWidth: '212px',
    height: '290px',
    borderRadius: '10px',
  },
}));
const CardActionsStyled = styled(CardActions)(({ theme }) => ({
  justifyContent: 'center',
  paddingBottom: '16px',
  [theme.breakpoints.down('sm')]: {
    marginTop: 0,
    padding: 0,
    paddingBottom: '16px',
  },
}));

export { StackBorder, IconButtonStyled, GridWrapper, CardStyled, CardActionsStyled };
