import React from 'react';
import Container from '@mui/material/Container';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { StackBG, CardContentStyled, ButtonStyled } from '@/sections/home/gallery/styles';
import RouterLink from '@/components/routerLink';

function GallerySection() {
  return (
    <Container maxWidth="xl">
      <Card
        sx={{
          position: 'relative',
          '&:hover': {
            boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
          },
        }}
      >
        <CardContentStyled>
          <Stack
            mt={{ xs: 2.5, sm: 7.5 }}
            mb={{ xs: 2.5, sm: 5 }}
            ml={{ xs: 0, sm: 7.5 }}
            justifyContent={{ xs: 'space-between', sm: 'space-between' }}
            alignItems={{ xs: 'center', sm: 'flex-start' }}
            sx={{ width: { xs: '100%', sm: '50%' }, zIndex: 2 }}
          >
            <Stack>
              <Typography variant="h2">Галерея</Typography>
              <Typography
                variant="body1"
                my={3.5}
                sx={{
                  maxWidth: { xs: 'auto', md: 510 },
                  display: { xs: 'none', sm: 'block' },
                  lineHeight: 1.25,
                }}
              >
                Демонстрация практического опыта, в последствии реализации различных задач клиентов
              </Typography>
            </Stack>

            <ButtonStyled
              variant="outlined"
              color="secondary"
              component={RouterLink}
              href={'/gallery'}
            >
              Смотреть
            </ButtonStyled>
          </Stack>
          <StackBG />
        </CardContentStyled>
      </Card>
    </Container>
  );
}

export default GallerySection;
