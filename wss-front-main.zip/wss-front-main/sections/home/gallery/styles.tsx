import React from 'react';
import Stack from '@mui/material/Stack';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';

const StackBG = styled(Stack)(({ theme }) => ({
  position: 'relative',
  boxShadow: '4px 4px 8px 0px #1E1E1E inset, -4px -4px 8px 0px rgba(77, 77, 77, 0.25) inset',
  width: '50%',
  backgroundImage:
    'linear-gradient(106deg, #181818 26.89%, rgba(24, 24, 24, 0.00) 100%), url("/assets/home/gun.png")',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'center',
  overflow: 'hidden',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '0',
    width: 0,
    height: 0,
    borderTop: '400px solid #181818',
    borderRight: '270px solid transparent',
    borderLeft: '0px solid transparent',
    zIndex: 1,
    filter: 'drop-shadow(4px 4px 8px #1E1E1E) drop-shadow(-4px -4px 8px rgba(77, 77, 77, 0.25))',
  },

  [theme.breakpoints.down('md')]: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    '&::before': {
      display: 'none',
    },
  },
}));

const CardContentStyled = styled(CardContent)(({ theme }) => ({
  display: 'flex',
  minHeight: 400,
  padding: '0px!important',

  [theme.breakpoints.down('sm')]: {
    minHeight: 162,
  },
}));

const ButtonStyled = styled(Button)<{ component?: React.ElementType }>(({ theme }) => ({
  width: '100%',
  minWidth: 190,
  maxWidth: 230,

  [theme.breakpoints.down('sm')]: {
    height: 50,
    fontSize: 16,
    maxWidth: 190,
  },
}));

export { StackBG, CardContentStyled, ButtonStyled };
