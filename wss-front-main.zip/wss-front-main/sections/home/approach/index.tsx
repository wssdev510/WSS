import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import AccordionApproach from '@/sections/home/approach/accordion';

const approach = [
  {
    title: 'Профессиональные эксперты',
    body: 'Основа нашего подхода – это высочайшая квалификация и профессионализм сотрудников. Работа нашего агентства основана на принципах системности, эффективности, планирования и распределения обязанностей. Мы гарантируем полную конфиденциальность и законность действий',
  },
  {
    title: 'Инновационные технологии',
    body: 'Использование и внедрение последних наработок в системе кибер– и технической безопасности, включая системы видеонаблюдения, биометрические методы аутентификации и мониторинг в режиме реального времени для обеспечения максимального контроля в любой ситуации',
  },
  {
    title: 'Персонализированный подход',
    body: 'Доверие, индивидуальные планы безопасности, анализ возможных угроз исходя из оперативной обстановки и требований обеспечивают нейтрализацию потенциальных угроз',
  },
  {
    title: 'Комплексное обеспечение',
    body: 'Предоставление полного спектра услуг, охватывающего все аспекты безопасности в различных сферах жизни',
  },
];

function ApproachSection() {
  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" mt={{ xs: 7, sm: 23 }} mb={{ xs: 5, sm: 10 }}>
        <Typography variant="h1" component="h2">
          Наш подход
        </Typography>
      </Stack>
      <AccordionApproach data={approach} />
      <Grid
        container
        rowSpacing={5}
        columnSpacing={5}
        justifyContent="space-between"
        sx={{ display: { xs: 'none', sm: 'flex' } }}
      >
        {approach.map((value, key) => (
          <Grid item xs={12} md={6} key={key}>
            <Box
              p={3}
              sx={{
                minHeight: 216,
                height: '100%',
                borderRadius: '10px',
                border: '1px solid #EA6303',
              }}
            >
              <Typography variant="h3" fontWeight={600} mb={3.5}>
                {value.title}
              </Typography>
              <Typography
                variant="body1"
                lineHeight="125%"
                sx={{ whiteSpace: 'break-spaces', maxWidth: 632 }}
              >
                {value.body}
              </Typography>
            </Box>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default ApproachSection;
