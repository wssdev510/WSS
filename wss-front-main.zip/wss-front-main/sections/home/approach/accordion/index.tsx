import * as React from 'react';
import { styled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, { AccordionSummaryProps } from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';

const Accordion = styled((props: AccordionProps) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(() => ({
  borderRadius: '10px',
  padding: '21px 16px 21px 24px',
  border: '1px solid #EA6303',
  marginTop: '20px',
  '&.Mui-expanded': {
    padding: '24px 16px 24px 24px',
  },
  '&:not(:last-child)': {},
  '&:before': {
    display: 'none',
  },
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
  <MuiAccordionSummary
    expandIcon={
      <ArrowForwardIosSharpIcon
        color="primary"
        sx={{ fontSize: '16px', transform: 'rotate(90deg)' }}
      />
    }
    {...props}
  />
))(() => ({
  padding: 0,
  margin: 0,
  minHeight: 'auto',
  alignItems: 'flex-start',
  '& .MuiAccordionSummary-content': {
    margin: 0,
  },
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(180deg)',
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(() => ({
  padding: 0,
}));

export default function AccordionApproach({ data }: { data: any }) {
  const [expanded, setExpanded] = React.useState<string | false>('panel0');

  const handleChange = (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
    setExpanded(newExpanded ? panel : false);
  };

  return (
    <Box sx={{ display: { xs: 'block', sm: 'none' } }}>
      {data?.map((item: any, key: number) => (
        <Accordion
          key={key}
          expanded={expanded === `panel${key}`}
          onChange={handleChange(`panel${key}`)}
        >
          <AccordionSummary>
            <Typography variant="subtitle2" fontWeight={600}>
              {item.title}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography
              mt={1.5}
              variant="body1"
              sx={{ whiteSpace: 'break-spaces', lineHeight: '18px' }}
            >
              {item.body}
            </Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
}
