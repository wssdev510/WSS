import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';

const BoxBG = styled(Box)(({ theme }) => ({
  background:
    "linear-gradient(180deg, rgba(24, 24, 24, 0.40) 0%, #181818 98.44%), url('/assets/home/bg.png'), lightgray",
  height: 780,
  backgroundRepeat: 'no-repeat, no-repeat, no-repeat',
  backgroundSize: 'cover, cover, cover',
  backgroundPosition: 'center, center, center',

  [theme.breakpoints.down('sm')]: {
    background: 'none',
    paddingTop: 105,
    height: 'auto',
  },
}));

const BoxTags = styled(Stack)(({ theme }) => ({
  display: 'inline-flex',
  padding: '10px 20px',
  borderRadius: '20px',
  border: '1px solid #878787',
  backgroundColor: '#181818',
  width: 'auto',
  textAlign: 'center',
  whiteSpace: 'nowrap',
  height: 40,
  alignItems: 'center',
  justifyContent: 'center',

  [theme.breakpoints.down('md')]: {
    width: 'auto',
  },
  [theme.breakpoints.down('sm')]: {
    width: 'auto',
    height: 37,
  },
}));

const StackWrap = styled(Stack)(({ theme }) => ({
  width: 'auto',
  maxWidth: 972,
  [theme.breakpoints.down('sm')]: {
    width: '100%',
  },
}));

const StyledButton = styled(Button)(({ theme }) => ({
  padding: '5px 56px',
  [theme.breakpoints.down('sm')]: {
    fontSize: 16,
    height: 50,
  },
}));

export { BoxBG, BoxTags, StackWrap, StyledButton };
