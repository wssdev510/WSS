import React from 'react';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import SocialLink from '@/components/socialLink';
import { BoxBG, BoxTags, StackWrap, StyledButton } from '@/sections/home/hero/styles';
import { useMultiModal } from '@/context/multiModalContext';

function HeroSection() {
  const { dispatch } = useMultiModal();

  const handleClickSecurityOpen = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'call' });
  };

  return (
    <BoxBG>
      <Container maxWidth="xl" sx={{ display: 'flex', height: '100%' }}>
        <Stack alignItems="center" justifyContent="center" sx={{ width: '100%', height: '100%' }}>
          <StackWrap
            mt={{ xs: 0, sm: 3.75 }}
            spacing={{ xs: 2.5, sm: 5.5 }}
            justifyContent="center"
            alignItems="center"
          >
            <Stack
              spacing={{ xs: 2.5, sm: 5 }}
              alignItems="center"
              sx={{ width: { xs: '100%', sm: 'auto' } }}
            >
              <Typography
                variant="h1"
                sx={{ textAlign: 'center', lineHeight: { xs: '32px', sm: 'normal' } }}
              >
                Ваша безопасность
                <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} />
                &nbsp;в наших руках
              </Typography>

              <Stack
                justifyContent="center"
                direction={{ xs: 'column', sm: 'row' }}
                sx={{ flexWrap: { xs: 'nowrap', sm: 'wrap' }, width: 'auto' }}
              >
                <BoxTags mb={2} mr={{ xs: 0, sm: 2.5 }}>
                  <Typography
                    variant="body1"
                    fontWeight={500}
                    sx={{ lineHeight: 1.2, fontSize: { xs: 12, sm: 16 } }}
                  >
                    квалифицированные сотрудники
                  </Typography>
                </BoxTags>

                <BoxTags mb={2} mr={{ xs: 0, sm: 2.5 }}>
                  <Typography
                    variant="body1"
                    fontWeight={500}
                    sx={{ lineHeight: 1.2, fontSize: { xs: 12, sm: 16 } }}
                  >
                    предоставляем услуги за 1 час
                  </Typography>
                </BoxTags>
                <BoxTags mb={2} mr={{ xs: 0, sm: 2.5, lg: 0 }}>
                  <Typography
                    variant="body1"
                    fontWeight={500}
                    sx={{ lineHeight: 1.2, fontSize: { xs: 12, sm: 16 } }}
                  >
                    профессиональная защита 24/7
                  </Typography>
                </BoxTags>
              </Stack>
            </Stack>

            <Stack
              spacing={{ xs: 2.5, sm: 3.75 }}
              ml={{ xs: 2, sm: 0 }}
              mr={{ xs: 2, sm: 0 }}
              alignItems="center"
              justifyContent="center"
            >
              <StyledButton
                variant="outlined"
                color="secondary"
                fullWidth
                onClick={handleClickSecurityOpen}
              >
                Заказать охрану
              </StyledButton>

              <SocialLink />
            </Stack>
          </StackWrap>
        </Stack>
      </Container>
    </BoxBG>
  );
}

export default HeroSection;
