import React from 'react';
import Container from '@mui/material/Container';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Element } from 'react-scroll';
import Transport from '@/sections/home/transport/transport';

function TransportSection() {
  return (
    <Element name="transport">
      <Container maxWidth="xl">
        <Stack alignItems="center" mt={{ xs: 10, sm: 22.5 }} mb={{ xs: 6, sm: 10 }}>
          <Typography variant="h1" component="h2" sx={{ textAlign: 'center' }}>
            Транспорт <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} />
            сопровождения
          </Typography>
        </Stack>

        <Box mb={{ xs: 10, sm: 22.5 }}>
          <Transport />
        </Box>
      </Container>
    </Element>
  );
}

export default TransportSection;
