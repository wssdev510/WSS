import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import Image from 'next/image';
import { styled } from '@mui/material/styles';

const CardContentStyled = styled(CardContent)(({ theme }) => ({
  padding: '32px',
  paddingTop: '20px',
  position: 'relative',
  height: '100%',
  '&:last-child': {
    paddingBottom: '40px',
  },
  [theme.breakpoints.down('sm')]: {
    padding: 0,
    paddingTop: '10px',
    '&:last-child': {
      paddingBottom: '8px',
    },
  },
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  width: '100%',
  maxWidth: 218,
  zIndex: 2,

  [theme.breakpoints.down('sm')]: {
    maxWidth: 183,
    height: 50,
    fontSize: 16,
  },
}));

const CardStyled = styled(Card)(({ theme }) => ({
  height: 400,
  '&:hover': {
    boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212, 0px 0px 4px 4px #EA6303',
  },
  [theme.breakpoints.down('sm')]: {
    borderRadius: '10px',
    height: 168,
  },
}));

const ImageStyled = styled(Image)(({ theme }) => ({
  width: 440,
  height: 256,
  [theme.breakpoints.down('sm')]: {
    width: 160,
    height: 90,
  },
}));

export { CardContentStyled, ButtonStyled, CardStyled, ImageStyled };
