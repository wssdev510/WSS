import React from 'react';
import Grid from '@mui/material/Grid';
import Link from '@mui/material/Link';
import RouterLink from '@/components/routerLink';
import {
  ButtonStyled,
  CardContentStyled,
  CardStyled,
  ImageStyled,
} from '@/sections/home/transport/styled';
import Stack from '@mui/material/Stack';
import Image from 'next/image';
import Typography from '@mui/material/Typography';

// import Swiper core and required modules
import { Navigation, Pagination } from 'swiper/modules';

import { Swiper, SwiperSlide } from 'swiper/react';
import GlobalStyles from '@mui/material/GlobalStyles';
import { useMultiModal } from '@/context/multiModalContext';

const data = [
  {
    isSlider: false,
    href: '/transport/mercedes-benz-g-class',
    image: '/assets/transport/Mercedes-Benz-G-class.png',
    title: 'Mercedes-Benz',
    titleBr: 'G-class',
  },
  {
    isSlider: false,
    href: '/transport/mercedes-benz-v-class',
    image: '/assets/transport/Mercedes-Benz-V-class.png',
    title: 'Mercedes-Benz',
    titleBr: 'V-class',
  },
  {
    isSlider: true,
    collection: [
      {
        href: '/transport/mercedes-s-class',
        image: '/assets/transport/Mercedes-S-class.png',
        title: 'Mercedes',
        titleBr: 'S-class',
      },
      {
        href: '/transport/bmw-7-series',
        image: '/assets/transport/BMW-7-series.png',
        title: 'BMW',
        titleBr: '7-series',
      },
    ],
  },
  {
    isSlider: true,
    collection: [
      {
        href: '/transport/mercedes-benz-e-class',
        image: '/assets/transport/Mercedes-Benz-E-class.png',
        title: 'Mercedes-Benz',
        titleBr: 'E-class',
      },
      {
        href: '/transport/bmw-5-series',
        image: '/assets/transport/BMW-5-series.png',
        title: 'BMW',
        titleBr: '5-series',
      },
    ],
  },
  {
    isSlider: false,
    isPlane: true,
    href: '/transport/business-jet',
    image: '/assets/transport/Plane.png',
    title: 'Бизнес-джет',
    titleBr: 'Бизнес-джет',
  },
];

function Transport() {
  const { dispatch } = useMultiModal();

  const handleClickOpen = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'call' });
  };

  return (
    <>
      <Grid container spacing={{ xs: 2.5, sm: 5 }}>
        {data.map((item: any, key: number) => {
          if (!item.isSlider) {
            return (
              <Grid item xs={12} md={6} key={key}>
                <Link underline="none" component={RouterLink} href={item.href || '/#'}>
                  <CardStyled>
                    <CardContentStyled>
                      <Stack justifyContent="center" alignItems="center">
                        <ImageStyled
                          src={item.image}
                          width={440}
                          height={256}
                          alt="transport"
                          quality={100}
                        />
                      </Stack>

                      <Typography mt={{ xs: 2, sm: 2.5 }} variant="h5" sx={{ textAlign: 'center' }}>
                        {!item.isPlane && (
                          <Typography
                            sx={{ display: { xs: 'none', sm: 'block' } }}
                            variant="h5"
                            component="span"
                          >
                            {item.title} <br />
                          </Typography>
                        )}
                        {item.titleBr}
                      </Typography>
                    </CardContentStyled>
                  </CardStyled>
                </Link>
              </Grid>
            );
          } else {
            return (
              <Grid item xs={12} md={6} key={key}>
                <CardStyled>
                  <Swiper
                    modules={[Navigation, Pagination]}
                    slidesPerView={1}
                    loop={true}
                    navigation
                    pagination={{ clickable: true }}
                  >
                    {item.collection?.map((slide: any, slideKey: number) => (
                      <SwiperSlide key={slideKey}>
                        <Link underline="none" component={RouterLink} href={slide.href}>
                          <CardContentStyled>
                            <Stack justifyContent="center" alignItems="center">
                              <ImageStyled
                                src={slide.image}
                                width={440}
                                height={256}
                                alt="transport"
                                quality={100}
                              />
                            </Stack>
                            <Typography mt={2} mb={2.5} sx={{ textAlign: 'center' }} variant="h5">
                              <Typography
                                sx={{ display: { xs: 'none', sm: 'block' } }}
                                variant="h5"
                                component="span"
                              >
                                {slide.title} <br />
                              </Typography>
                              {slide.titleBr}
                            </Typography>
                          </CardContentStyled>
                        </Link>
                      </SwiperSlide>
                    ))}
                  </Swiper>
                </CardStyled>
              </Grid>
            );
          }
        })}
        <Grid item xs={12} md={6}>
          <CardStyled sx={{ height: { xs: 304, sm: 400 } }}>
            <CardContentStyled
              sx={{
                position: 'relative',
                paddingTop: '20px',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                '&:last-child': {
                  paddingBottom: '24px',
                },
              }}
            >
              <Stack sx={{ width: '100%' }} alignItems={{ xs: 'center', sm: 'flex-start' }}>
                <Typography
                  variant="h5"
                  mt={{ xs: 1, sm: 4 }}
                  sx={{ zIndex: 2, textAlign: { xs: 'center', sm: 'left' } }}
                >
                  Транспорт по запросу
                </Typography>
                <Typography
                  variant="body1"
                  mb={13}
                  mt={2.5}
                  sx={{
                    display: { xs: 'none', sm: 'block' },
                    zIndex: 2,
                    textAlign: { xs: 'center', sm: 'left' },
                    lineHeight: 1.25,
                  }}
                >
                  Мы можем предоставить любой <br /> необходимый транспорт
                </Typography>

                <Stack mt={2} mb={2} sx={{ display: { xs: 'flex', sm: 'none' } }}>
                  <Image
                    quality={100}
                    src="/assets/transport/Transport-on-request.png"
                    width={160}
                    height={160}
                    alt="transport"
                    style={{ mixBlendMode: 'lighten' }}
                  />
                </Stack>

                <ButtonStyled variant="outlined" color="secondary" onClick={handleClickOpen}>
                  Заказать
                </ButtonStyled>
              </Stack>
              <Stack
                sx={{
                  display: { xs: 'none', sm: 'flex' },
                  position: 'absolute',
                  bottom: 0,
                  right: 0,
                }}
              >
                <Image
                  quality={100}
                  src="/assets/transport/Transport-on-request.png"
                  width={342}
                  height={342}
                  alt="transport"
                  style={{ mixBlendMode: 'lighten' }}
                />
              </Stack>
            </CardContentStyled>
          </CardStyled>
        </Grid>
      </Grid>

      <GlobalStyles
        styles={{
          '.swiper.swiper': {
            overflowY: 'visible',
            paddingLeft: 16,
            paddingRight: 16,
          },
          '.swiper-pagination': {
            marginBottom: '20px',
            '@media (max-width: 600px)': {
              marginBottom: '-2px',
            },
          },
          '.swiper-pagination-bullet.swiper-pagination-bullet': {
            width: 12,
            height: 12,
            background: '#E9E9E9',
            opacity: 1,
            '@media (max-width: 600px)': {
              width: '6px',
              height: '6px',
              margin: '0 2px !important',
            },
          },
          '.swiper-pagination-bullet.swiper-pagination-bullet-active': {
            background: '#EA6303',
          },
          '.swiper-button-prev.swiper-button-prev:after': {
            color: '#D3D3D3',
            fontSize: '18px',
            '@media (max-width: 600px)': {
              fontSize: '6px',
            },
          },
          '.swiper-button-next.swiper-button-next:after': {
            color: '#D3D3D3',
            fontSize: '18px',
            '@media (max-width: 600px)': {
              fontSize: '6px',
            },
          },
          '.swiper-button-next.swiper-button-next': {
            marginRight: 30,
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            border: '1px solid #EA6303',
            boxShadow: '4.8px 4.8px 9.6px 0px #1E1E1E, -4.8px -4.8px 9.6px 0px #121212',
            '@media (max-width: 600px)': {
              width: '20px',
              height: '20px',
              marginRight: 8,
              marginTop: 'calc(0px - (20px / 2))',
            },
          },
          '.swiper-button-prev.swiper-button-prev': {
            marginLeft: 30,
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            border: '1px solid #EA6303',
            boxShadow: '4.8px 4.8px 9.6px 0px #1E1E1E, -4.8px -4.8px 9.6px 0px #121212',
            '@media (max-width: 600px)': {
              width: '20px',
              height: '20px',
              marginLeft: 8,
              marginTop: 'calc(0px - (20px / 2))',
            },
          },
        }}
      />
    </>
  );
}

export default Transport;
