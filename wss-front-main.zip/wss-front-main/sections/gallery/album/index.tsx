import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import { styled } from '@mui/material/styles';
import Skeleton from '@mui/material/Skeleton';
import { usePathname } from 'next/navigation';
import { fetchGalleryId } from '@/firebase/api';
import PlaceholderImage from '@/components/PlaceholderImage';

const StackCard = styled(Card)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
  width: '100%',
  height: 284,
  position: 'relative',
  borderRadius: '20px',
  boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
  overflow: 'hidden',
  '&::before': {
    content: '""',
    position: 'absolute',
    zIndex: 2,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.3) 0%, rgba(0, 0, 0, 0.3) 100%)',
    opacity: 1,
    transition: 'opacity 1s ease',
  },

  [theme.breakpoints.down('md')]: {
    height: '400px',
  },
  [theme.breakpoints.down('sm')]: {
    height: '284px',
  },

  '&:hover': {
    '&:hover::before': {
      opacity: 0,
    },
  },
}));

function AlbumSection() {
  const pathname = usePathname();
  const [loading, setLoading] = useState(true);
  const [documentData, setDocumentData] = useState<any>({});

  useEffect(() => {
    setLoading(true);
    const parts = pathname.split('/');
    const id = parts[parts.length - 1];

    fetchGalleryId(id)
      .then((res) => setDocumentData(res))
      .finally(() => setLoading(false));
  }, [pathname]);

  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" mt={{ xs: 4, sm: 7.5 }} mb={{ xs: 7, sm: 14 }}>
        <Typography variant="h1">
          {loading ? <Skeleton width={300} variant="text" /> : documentData?.title}
        </Typography>
      </Stack>

      <Grid container spacing={5}>
        {loading
          ? Array.from(new Array(6)).map((_, index) => (
              <Grid item xs={12} md={6} lg={4} key={index}>
                <Stack
                  sx={{
                    width: '100%',
                    borderRadius: '20px',
                    overflow: 'hidden',
                    boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
                  }}
                >
                  <Skeleton
                    variant="rectangular"
                    sx={{
                      height: { xs: '284px', sm: '400px', md: '284px' },
                    }}
                    animation="wave"
                  />
                </Stack>
              </Grid>
            ))
          : documentData?.album?.map((value: any, key: number) => (
              <Grid item xs={12} md={6} lg={4} key={key}>
                <StackCard>
                  <CardContent>
                    <PlaceholderImage
                      style={{
                        objectFit: 'cover',
                      }}
                      fill
                      alt="gallery"
                      src={value.img}
                    />
                  </CardContent>
                </StackCard>
              </Grid>
            ))}
      </Grid>
    </Container>
  );
}

export default AlbumSection;
