import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import RouterLink from '@/components/routerLink';
import Link from '@mui/material/Link';
import Skeleton from '@mui/material/Skeleton';
import { fetchGalleryCollection, fetchTagsCollection } from '@/firebase/api';
import { DocumentData } from '@firebase/firestore-types';
import PlaceholderImage from '@/components/PlaceholderImage';

const ButtonStyled = styled(Button)(({ theme, variant }) => {
  const hoverStyles =
    variant === 'contained'
      ? {
          border: '1px solid #EA6303',
          '&:hover': {
            backgroundColor: '#EA6303',
            boxShadow:
              '4px 4px 8px 0px #1E1E1E inset, -4px -4px 8px 0px rgba(77, 77, 77, 0.25) inset, 10px 10px 20px 0px #1E1E1E, -10px -10px 20px 0px #121212',
          },
        }
      : {};

  return {
    marginBottom: '20px',
    marginRight: '20px',
    textTransform: 'none',
    padding: '5px 40px',
    borderRadius: '13px',
    fontWeight: 400,
    boxShadow:
      '4px 4px 8px 0px #1E1E1E inset, -4px -4px 8px 0px rgba(77, 77, 77, 0.25) inset, 10px 10px 20px 0px #1E1E1E, -10px -10px 20px 0px #121212',
    ...hoverStyles,
    [theme.breakpoints.down('sm')]: {
      fontSize: 16,
    },
  };
});

const StackCard = styled(Stack)(({ theme }) => ({
  cursor: 'pointer',
  width: '100%',
  position: 'relative',
  overflow: 'hidden',
  height: '400px',
  borderRadius: '20px',
  boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
  '&::before': {
    content: '""',
    zIndex: 2,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'linear-gradient(0deg, rgba(0, 0, 0, 0.55) 0%, rgba(0, 0, 0, 0.55) 100%)',
    opacity: 1,
    transition: 'opacity 1s ease',
  },
  '&:hover::before': {
    opacity: 0,
  },

  [theme.breakpoints.down('sm')]: {
    height: '284px',
  },
}));

function HeroGallerySection() {
  const [tags, setTags] = useState<DocumentData[]>([]);
  const [albums, setAlbums] = useState<DocumentData[]>([]);
  const [isToggled, setIsToggled] = useState('all');
  const [loading, setLoading] = useState(true);
  const [loadingTag, setLoadingTag] = useState(true);

  const handleToggle = (value: string) => {
    if (value !== isToggled) {
      setIsToggled(value);
    }
  };

  useEffect(() => {
    setLoading(true);
    if (tags.length === 0) {
      setLoadingTag(true);
      fetchTagsCollection()
        .then((res: any) => setTags(res))
        .finally(() => setLoadingTag(false));
    }

    fetchGalleryCollection(isToggled)
      .then((res: any) => setAlbums(res))
      .finally(() => setLoading(false));
  }, [isToggled, tags]);

  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" mt={{ xs: 4, sm: 7.5 }}>
        <Typography variant="h1" mb={{ xs: 3, sm: 5 }}>
          Галерея безопасности
        </Typography>

        <Typography
          variant="subtitle1"
          sx={{ lineHeight: 1.4, maxWidth: 618, textAlign: 'center' }}
        >
          Изображения демонстрирующие нашу экспертизу и практический опыт в сфере охраны,
          подчеркивающие наше стремление к надежности и профессионализму
        </Typography>
      </Stack>

      <Stack
        direction="row"
        mt={{ xs: 7, sm: 12.5 }}
        mb={5}
        sx={{ flexWrap: 'wrap', minHeight: 40 }}
      >
        {loadingTag
          ? Array.from(new Array(5)).map((_, index) => (
              <Box
                mr={2.5}
                mb={2.5}
                key={index}
                sx={{
                  borderRadius: '13px',
                  overflow: 'hidden',
                  boxShadow:
                    '4px 4px 8px 0px #1E1E1E inset, -4px -4px 8px 0px rgba(77, 77, 77, 0.25) inset, 10px 10px 20px 0px #1E1E1E, -10px -10px 20px 0px #121212',
                }}
              >
                <Skeleton
                  variant="rectangular"
                  sx={{ width: { xs: 140, sm: 210 } }}
                  height={40}
                  animation="wave"
                />
              </Box>
            ))
          : tags.map((item, key) => (
              <ButtonStyled
                key={key}
                size="small"
                variant={item.id === isToggled ? 'contained' : 'outlined'}
                color="secondary"
                onClick={() => handleToggle(item.id)}
              >
                {item.title}
              </ButtonStyled>
            ))}
      </Stack>

      <Grid container spacing={5}>
        {loading
          ? Array.from(new Array(4)).map((_, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Stack
                  sx={{
                    width: '100%',
                    borderRadius: '20px',
                    overflow: 'hidden',
                    boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #121212',
                  }}
                >
                  <Skeleton
                    variant="rectangular"
                    sx={{
                      height: { xs: '284px', sm: '400px' },
                    }}
                    animation="wave"
                  />
                </Stack>
              </Grid>
            ))
          : albums.map((value, key) => (
              <Grid key={key} item xs={12} md={6}>
                <Link underline="none" component={RouterLink} href={`gallery/${value.id}`}>
                  <StackCard alignItems="center" justifyContent="center">
                    <PlaceholderImage
                      style={{
                        objectFit: 'cover',
                      }}
                      fill
                      alt="gallery"
                      src={value.img}
                    />
                    <Stack mt={13} />
                    <Typography
                      variant="h2"
                      fontWeight={700}
                      sx={{ position: 'absolute', textAlign: 'center', zIndex: 3 }}
                    >
                      {value.title}
                    </Typography>
                  </StackCard>
                </Link>
              </Grid>
            ))}
      </Grid>
    </Container>
  );
}

export default HeroGallerySection;
