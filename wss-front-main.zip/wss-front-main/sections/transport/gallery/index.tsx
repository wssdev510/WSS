import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Grid from '@mui/material/Grid';
import { styled } from '@mui/material/styles';
import PlaceholderImage from '@/components/PlaceholderImage';

const BoxStyled = styled(Card)(({ theme }) => ({
  display: 'flex',
  width: '100%',
  position: 'relative',
  overflow: 'hidden',
  borderRadius: '13px',
  height: '400px',
  justifyContent: 'center',
  alignItems: 'center',
  [theme.breakpoints.down('sm')]: {
    height: '160px',
  },
}));

function GalleryCarSection({ transport }: any) {
  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" mt={{ xs: 9, sm: 15.5 }} mb={{ xs: 3.75, sm: 12.5 }}>
        <Typography variant="h1" component="h2">
          Галерея
        </Typography>
      </Stack>

      <Grid container spacing={5}>
        {transport?.gallery?.map((value: { alt: string; image: string }, key: number) => (
          <Grid item xs={12} md={6} key={key}>
            <BoxStyled>
              <CardContent>
                <PlaceholderImage
                  style={{
                    objectFit: 'cover',
                  }}
                  fill
                  alt={value.alt ?? 'transport gallery'}
                  src={value.image}
                />
              </CardContent>
            </BoxStyled>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default GalleryCarSection;
