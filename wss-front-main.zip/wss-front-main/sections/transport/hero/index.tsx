import React from 'react';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import SocialLink from '@/components/socialLink';
import Image from 'next/image';
import { styled, useTheme } from '@mui/material/styles';
import { BoxTags } from '@/sections/home/hero/styles';
import Skeleton from '@mui/material/Skeleton';
import { usePathname } from 'next/navigation';
import { useMultiModal } from '@/context/multiModalContext';
import useMediaQuery from '@mui/material/useMediaQuery';

const ButtonStyled = styled(Button)(({ theme }) => ({
  padding: '5px 28px',
  fontSize: 24,
  width: '100%',
  maxWidth: 218,

  [theme.breakpoints.down('sm')]: {
    maxWidth: 183,
    fontSize: 16,
    height: 50,
  },
  [theme.breakpoints.down('lg')]: {
    padding: '5px 20px',
  },
}));

const maskTransport = [
  {
    key: 'mercedes-benz-g-class',
    name: 'Mercedes G-сlass',
    image: '/assets/transport/Mercedes-Benz-G-class.png',
  },
  {
    key: 'mercedes-benz-v-class',
    name: 'Mercedes V-сlass',
    image: '/assets/transport/Mercedes-Benz-V-class.png',
  },
  {
    key: 'mercedes-s-class',
    name: 'Mercedes S-сlass',
    image: '/assets/transport/Mercedes-S-class.png',
  },
  {
    key: 'bmw-7-series',
    name: 'BMW 7-series',
    image: '/assets/transport/BMW-7-series.png',
  },
  {
    key: 'mercedes-benz-e-class',
    name: 'Mercedes E-сlass',
    image: '/assets/transport/Mercedes-Benz-E-class.png',
  },
  {
    key: 'bmw-5-series',
    name: 'BMW 5-series',
    image: '/assets/transport/BMW-5-series.png',
  },
  {
    key: 'business-jet',
    name: 'Бизнес-джет',
    image: '/assets/transport/Plane.png',
  },
];

function HeroCarSection({ transport, loading }: { transport: any; loading: boolean }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const pathname = usePathname();
  const { dispatch } = useMultiModal();

  const handleClickSecurityOpen = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'call' });
  };

  return (
    <Container maxWidth="xl">
      <Grid
        mt={{ xs: 0, sm: 4 }}
        direction={{ xs: 'column-reverse', lg: 'row' }}
        justifyContent={{ xs: 'center', lg: 'flex-start' }}
        alignItems={{ xs: 'center', lg: 'flex-start' }}
        container
        spacing={{ xs: 2, sm: 4 }}
      >
        <Grid item xs={12} sm={9} lg={6}>
          {!isMobile && (
            <Typography variant="h1" sx={{ display: { xs: 'none', sm: 'block' } }}>
              {maskTransport.find((x) => x.key === pathname.split('/').pop())?.name}
            </Typography>
          )}

          {(loading || (isMobile && transport?.price)) && (
            <Stack alignItems="center" sx={{ width: '100%' }} mb={4}>
              <Typography
                variant="h2"
                fontWeight={700}
                color="secondary"
                sx={{
                  display: { xs: 'block', sm: 'none' },
                  textAlign: 'center',
                  fontSize: { xs: 16 },
                }}
              >
                {loading ? <Skeleton width={200} variant="text" /> : transport?.price}
              </Typography>
            </Stack>
          )}

          {pathname.split('/').pop() === 'business-jet' ? (
            loading ? (
              <Box px={{ xs: 3, sm: 0 }} mt={3.75} mb={2.5} sx={{ width: '100%', minWidth: 270, maxWidth: 540 }}>
                <Skeleton variant="text" width="100%" height={24} />
                <Skeleton variant="text" width="100%" height={24} />
                <Skeleton variant="text" width="100%" height={24} />
              </Box>
            ) : (
              <Typography
                mt={3.75}
                mb={2.5}
                px={{ xs: 3, sm: 0 }}
                variant="subtitle1"
                component="p"
                fontWeight={400}
                sx={{ maxWidth: { xs: 'auto', md: 555 }, lineHeight: '28px' }}
              >
                {transport?.body}
              </Typography>
            )
          ) : (
            (transport?.tags || loading) && (
              <Stack
                mt={3}
                px={{ xs: 3, sm: 0 }}
                direction={{ xs: 'column', sm: 'row' }}
                alignItems="center"
                sx={{ flexWrap: { xs: 'nowrap', sm: 'wrap' }, minWidth: 270, maxWidth: 535 }}
              >
                {loading
                  ? [1, 2, 3].map((item) => (
                      <Box mb={2.5} mr={{ xs: 0, sm: 2.5 }} key={item}>
                        <Skeleton width={240} height={40} variant="text" />
                      </Box>
                    ))
                  : transport?.tags?.map(
                      (item: string, key: number) =>
                        item && (
                          <BoxTags
                            sx={{
                              width: { xs: '100%', sm: 'auto' },
                              padding: { xs: '7px', sm: '7px 20px' },
                            }}
                            mb={2.5}
                            mr={{ xs: 0, sm: 2.5 }}
                            key={key}
                          >
                            <Typography
                              variant="body1"
                              fontWeight={500}
                              sx={{ fontSize: { xs: 12, sm: 16 } }}
                            >
                              {item}
                            </Typography>
                          </BoxTags>
                        )
                    )}
              </Stack>
            )
          )}
          {!isMobile && (
            <Typography
              mt={6}
              mb={3}
              variant="h2"
              fontWeight={700}
              color="secondary"
              sx={{ display: { xs: 'none', sm: 'block' } }}
            >
              {loading ? <Skeleton width={300} variant="text" /> : transport?.price}
            </Typography>
          )}

          <Stack
            direction={{ xs: 'column', sm: 'row' }}
            spacing={{ xs: 2.5, sm: 3.75 }}
            alignItems="center"
          >
            <ButtonStyled variant="outlined" color="secondary" onClick={handleClickSecurityOpen}>
              Заказать
            </ButtonStyled>
            <SocialLink />
          </Stack>
        </Grid>
        <Grid container alignItems="center" justifyContent="center" item xs={12} sm={9} lg={6}>
          {(isMobile || loading) && (
            <Stack alignItems="center" sx={{ width: '100%' }}>
              <Typography
                variant="h1"
                sx={{ display: { xs: 'flex', sm: 'none' }, textAlign: 'center' }}
              >
                {maskTransport.find((x) => x.key === pathname.split('/').pop())?.name}
              </Typography>
            </Stack>
          )}
          <Box sx={{ display: 'flex', width: '100%', maxWidth: 680 }}>
            <Image
              quality={100}
              alt="transport"
              width={680}
              height={382}
              style={{
                width: '100%',
                height: 'auto',
              }}
              src={maskTransport.find((x) => x.key === pathname.split('/').pop())?.image ?? ''}
            />
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}

export default HeroCarSection;
