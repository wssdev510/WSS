import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import { BoxBorderStyled } from '@/sections/bodyguard/price';
import CheckIcon from '@mui/icons-material/Check';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import Box from '@mui/material/Box';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

const info = [
  <>
    Консультирование и подготовку рекомендаций по вопросам защиты от противоправных посягательств, в
    том числе оценку угроз, разработку планов безопасности{' '}
    <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> и рекомендации
    <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> по предотвращению
    преступлений или других рисков
  </>,
  'Сбор, анализ и систематизацию информации, установление обстоятельств происшествий, событий, участвующих лиц',
  'Изучение рынка, сбор информации для деловых переговоров, выявление некредитоспособных или ненадежных деловых партнеров',
  'Сбор сведений по гражданским делам на договорной основе с участниками процесса',
  'Установление обстоятельств неправомерного использования в предпринимательской деятельности фирменных знаков и наименований, недобросовестной конкуренции, а также разглашения сведений, составляющих коммерческую тайну',
  'Выяснение биографических и других характеризующих личность данных об отдельных гражданах (с их письменного согласия) при заключении ими трудовых и иных контрактов',
  'Поиск без вести пропавших граждан',
  'Поиск лица, являющегося должником в соответствии с исполнительным документом',
];

function DetectiveSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title="Детективные услуги"
        body="Частный детектив проведет оперативную работу и расследование в личной, семейной,
          коммерческой или рабочей сфере"
      />

      <CardBgService
        price={price?.detective}
        loading={loading}
        image="/assets/service/detective.png"
      />

      <Grid container mt={{ xs: 4.5, sm: 10 }} columnSpacing={{ xs: 2.5, sm: 5 }} rowSpacing={2.5}>
        {info.map((item, key) => (
          <Grid item xs={12} md={6} key={key}>
            <BoxBorderStyled key={key} sx={{ height: 160, padding: { xs: '16px', lg: '40px' } }}>
              <Stack
                direction="row"
                spacing={{ xs: 1.8, sm: 3.5 }}
                alignItems={{ xs: 'flex-start', sm: 'center' }}
                sx={{ height: '100%' }}
              >
                <CheckIcon sx={{ fontSize: { xs: 16, sm: 24 } }} />
                <Typography variant="body1" sx={{ lineHeight: { xs: '128.571%', sm: '125%' } }}>
                  {item}
                </Typography>
              </Stack>
            </BoxBorderStyled>
          </Grid>
        ))}
      </Grid>
      <Grid container mt={2.5} justifyContent="center">
        <Grid item xs={12} md={6}>
          <BoxBorderStyled sx={{ height: 160, padding: { xs: '16px', lg: '40px' } }}>
            <Stack
              direction="row"
              spacing={{ xs: 2, sm: 3.5 }}
              alignItems={{ xs: 'flex-start', sm: 'center' }}
              sx={{ height: '100%' }}
            >
              <CheckIcon sx={{ fontSize: { xs: 16, sm: 24 } }} />
              <Typography variant="body1" sx={{ lineHeight: '125%' }}>
                Сбор сведений по уголовным делам на договорной основе с участниками процесса
              </Typography>
            </Stack>
          </BoxBorderStyled>
        </Grid>
      </Grid>

      <Stack alignItems="center" justifyContent="center" mt={{ xs: 2.5, sm: 8 }}>
        <Card sx={{ width: '100%', maxWidth: 680 }}>
          <CardContent
            sx={{
              padding: { xs: '24px', sm: '40px' },
              '&:last-child': {
                paddingBottom: { xs: '24px', sm: '40px' },
              },
            }}
          >
            <Typography variant="body1" sx={{ lineHeight: { xs: '128.571%', sm: '125%' } }}>
              * Мы сохраняем полную конфиденциальность полученных сведений и результатов работы с
              предоставлением отчетности. <br />
              <br />* Все виды детективных услуг предоставляются в соответствии с федеральным
              законом «О частной детективной и охранной деятельности в Российской Федерации»
            </Typography>
          </CardContent>
        </Card>
      </Stack>
    </Container>
  );
}

export default DetectiveSection;
