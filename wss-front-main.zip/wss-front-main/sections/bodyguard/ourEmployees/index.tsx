import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Image from 'next/image';

function OurEmployees() {
  return (
    <Container maxWidth="xl">
      <Typography
        mb={{ xs: 2.5, md: 10 }}
        fontWeight={500}
        variant="h3"
        sx={{ textAlign: 'center', fontSize: { xs: 14, sm: 32 } }}
      >
        Кто наши сотрудники
      </Typography>

      <Grid container columnSpacing={5}>
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              width: '100%',
              height: { xs: '100%', md: 'auto' },
              maxHeight: 482,
              borderRadius: '13px',
            }}
          >
            <Image
              src="/assets/service/bodyguard.png"
              width={680}
              height={482}
              alt="bodyguard"
              style={{ width: '100%', height: '100%' }}
            />
          </Box>
        </Grid>

        <Grid item xs={12} sm={6} mt={{ xs: 2, md: 0 }}>
          <Card>
            <CardContent
              sx={{
                padding: { xs: '24px', md: '40px' },
                '&:last-child': {
                  paddingBottom: { xs: '24px', md: '50px' },
                },
              }}
            >
              <Typography variant="subtitle1" sx={{ lineHeight: { xs: '128% ', sm: '140%' } }}>
                Все наши телохранители – профессионалы с аналитическим складом ума, нестандартным
                мышлением и высоким уровнем интеллектуального развития, прошедшие
                <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> длительную и
                сложную подготовку в области <br /> безопасности.
                <br />
                <br />
                Безупречная репутация, слаженная работа и наличие всех необходимых навыков и
                снаряжения позволяют обеспечить защиту и эффективно действовать в нестандартной
                ситуации.
                <br />
                <br />
                Личная охрана сегодня – это выбор дальновидных людей, которые предпочитают доверять
                безопасность своей персоны, а также своих родных и близких профессионалам
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}

export default OurEmployees;
