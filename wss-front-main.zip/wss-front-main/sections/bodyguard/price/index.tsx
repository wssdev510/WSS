import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import { styled } from '@mui/material/styles';
import ServicePrice from '@/components/servicePrice';
import TitleService from '@/components/tittleService';
import { fetchDocAndSubCollection } from '@/firebase/api';
import { DocumentData } from '@firebase/firestore-types';
import Skeleton from '@mui/material/Skeleton';

export const BoxBorderStyled = styled(Box)(({ theme }) => ({
  borderRadius: '20px',
  border: '1px solid #EA6303',
  padding: '40px',
  height: '100%',

  [theme.breakpoints.down('sm')]: {
    borderRadius: '10px',
    padding: '16px',
    height: 'auto',
  },
}));

const info = [
  {
    title: 'Медийная охрана',
    body: (
      <>
        Особенно актуально для публичных людей представителей шоу бизнеса, политики и
        ивент-индустрии, часто появляющихся
        <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> в людных местах. <br />{' '}
        <br /> В первую очередь это защита от провокаций и риска физической доступности
      </>
    ),
  },
  {
    title: 'Сопровождение',
    body: 'При необходимости скрыть присутствие личной охраны клиента',
  },
  {
    title: (
      <>
        Охрана при возникновении <br /> реальной угрозы
      </>
    ),
    body: 'Обеспечение безопасности и сохранности жизни штурмовой группой при реальной угрозе запланированного нападения',
  },
  {
    title: 'Скрытая безопасность',
    body: 'Телохранитель в течение необходимого вам времени находятся рядом с вами и обеспечивают нейтрализацию потенциальных угроз',
  },
];

function BodyguardPriceSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title="Телохранитель"
        body="Наши телохранители имеют многолетний опыт работы с ВИП персонами и первыми лицами
            государства, и осуществляют полный комплекс защитных мер, основная задача которых –
            обеспечение личной безопасности клиента и нейтрализация потенциальных угроз"
      />

      <Box mt={{ xs: 4, sm: 7.5 }}>
        <Stack alignItems="center" mb={3} sx={{ display: { xs: 'flex', sm: 'none' } }}>
          <Typography
            variant="h2"
            fontWeight={700}
            color="secondary"
            sx={{ textAlign: 'center', fontSize: '16px' }}
          >
            {loading ? <Skeleton variant="text" width={120} /> : price?.bodyguard}
          </Typography>
        </Stack>

        <ServicePrice price={price?.bodyguard} loading={loading} />
      </Box>

      <Grid container spacing={{ xs: 2.5, sm: 5 }} mt={{ xs: 5, sm: 10 }} mb={{ xs: 8.5, sm: 15 }}>
        {info.map((item, key) => (
          <Grid item xs={12} md={6} key={key}>
            <BoxBorderStyled sx={{ minHeight: { xs: 'auto', sm: 300 } }}>
              <Typography
                fontWeight={500}
                variant="h3"
                mb={{ xs: 1.5, sm: 2.5 }}
                sx={{
                  fontSize: { xs: 14, sm: 32 },
                  lineHeight: { xs: '128.571%', sm: '150%' },
                }}
              >
                {item.title}
              </Typography>

              <Typography variant="body1" sx={{ lineHeight: '128.571%' }}>
                {item.body}
              </Typography>
            </BoxBorderStyled>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default BodyguardPriceSection;
