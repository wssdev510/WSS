import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Box from '@mui/material/Box';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

function PersonnelSelectionSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);


  return (
    <Container maxWidth="xl">
      <TitleService
        title={
          <>
            Кадровый <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> подбор
            <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> сотрудников
          </>
        }
        body="Наша команда профессионалов проведет тщательную проверку потенциальных сотрудников на
          предмет соответствия вашим требованиям и предпочтениям"
      />

      <CardBgService price={price?.personnelSelection} loading={loading} image="/assets/service/personnel-selection.png" />

      <Stack alignItems="center" justifyContent="center" mt={{ xs: 8, sm: 13 }}>
        <Card sx={{ width: '100%', maxWidth: 920 }}>
          <CardContent
            sx={{
              padding: { xs: '24px', sm: '40px', md: '40px 85px 60px 85px' },
              '&:last-child': {
                paddingBottom: { xs: '24px', sm: '40px', md: '60px' },
              },
            }}
          >
            <Typography variant="subtitle1" sx={{ lineHeight: { xs: '128.571%', sm: '140%' } }}>
              Содействие в кадровом подборе личного персонала включает в себя выяснение
              биографических характеристик кандидата, подлинности{' '}
              <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> его рекомендаций
              и репутации, а также обязательную проверку психологической устойчивости.
              <br />
              <br />
              Кроме образования и опыта, мы акцентируем внимание{' '}
              <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> на таких
              качествах работников, как ответственность, аккуратность, порядочность,
              коммуникабельность и умение контролировать свои эмоции.
              <br />
              <br />
              Уверенность в надежности и профессионализме личного персонала –{' '}
              <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} /> это важный аспект
              безопасности вас и вашей семьи
            </Typography>
          </CardContent>
        </Card>
      </Stack>
    </Container>
  );
}

export default PersonnelSelectionSection;
