import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Image from 'next/image';
import { styled } from '@mui/material/styles';

const CustomTypography = styled(Typography)({
  position: 'relative',
  lineHeight: 1.4,
  '&::before': {
    content: '""',
    position: 'absolute',
    left: 0,
    top: '50%',
    transform: 'translateY(-50%)',
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    backgroundColor: '#E9E9E9',
    marginRight: '5px',
  },
});
function EmployeesSection() {
  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" mt={{ xs: 10, md: 15 }} mb={{ xs: 5, md: 10 }}>
        <Typography variant="h3">Кто наши сотрудники</Typography>
      </Stack>

      <Grid
        container
        direction={{ xs: 'column-reverse', md: 'row' }}
        rowSpacing={5}
        columnSpacing={{ xs: 0, md: 5 }}
      >
        <Grid item xs={12} md={6}>
          <Box sx={{ position: 'relative' }}>
            <Image
              src="/assets/security/image.png"
              style={{ width: '100%', height: 'auto' }}
              width={680}
              height={482}
              alt="secutity"
            />
            <Box
              sx={{
                top: '50%',
                right: 0,
                position: 'absolute',
              }}
            >
              <Image
                src="/assets/security/grid.png"
                style={{ width: '100%', height: 'auto' }}
                width={680}
                height={556}
                alt="secutity"
              />
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Stack spacing={5}>
            <CustomTypography variant="subtitle1" pl={3}>
              Бывшие и действующие сотрудники силовых ведомств
            </CustomTypography>
            <CustomTypography pl={3} variant="subtitle1">
              Ветераны боевых конфликтов
            </CustomTypography>
            <CustomTypography pl={3} variant="subtitle1">
              Спортсмены боевых видов спорта
            </CustomTypography>
          </Stack>

          <Typography component="p" variant="subtitle1" mt={7.5} sx={{ lineHeight: 1.4 }}>
            Lorem ipsum dolor sit amet consectetur. Augue nec morbi a sed. Placerat consectetur
            dictum vestibulum venenatis malesuada a dui sollicitudin pulvinar.
            <br />
            <br />
            Viverra amet scelerisque in massa accumsan fusce cursus. Vel non commodo quis quam
            viverra ullamcorper nibh blandit at. Id fringilla purus eleifend dolor venenatis tellus
            tortor elementum interdum. Amet diam nibh quisque vulputate tincidunt et pulvinar. Eget
            tempor.
          </Typography>
        </Grid>
      </Grid>
    </Container>
  );
}

export default EmployeesSection;
