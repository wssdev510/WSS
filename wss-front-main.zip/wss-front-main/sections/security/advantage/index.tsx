import React from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Image from 'next/image';

function AdvantageSection() {
  return (
    <Container maxWidth="xl">
      <Stack alignItems="center" justifyContent="center">
        <Typography variant="h3" mt={{ xs: 10, md: 15 }} mb={{ xs: 5, md: 10 }}>
          Преимущества
        </Typography>

        <Stack spacing={5}>
          <Stack direction="row" alignItems="center" spacing={4}>
            <Stack>
              <Image width={60} height={75} src="/assets/home/shield.png" alt="image" />
            </Stack>
            <Typography variant="subtitle1" fontWeight={400}>
              Гарантированная защита в любое время и в любом месте
            </Typography>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={4}>
            <Stack>
              <Image width={60} height={75} src="/assets/home/shield.png" alt="image" />
            </Stack>
            <Typography variant="subtitle1" fontWeight={400}>
              Гарантированная защита в любое время и в любом месте
            </Typography>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={4}>
            <Stack>
              <Image width={60} height={75} src="/assets/home/shield.png" alt="image" />
            </Stack>
            <Typography variant="subtitle1" fontWeight={400}>
              Гарантированная защита в любое время и в любом месте
            </Typography>
          </Stack>
        </Stack>
      </Stack>
    </Container>
  );
}

export default AdvantageSection;
