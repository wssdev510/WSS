import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

function VideoSystemSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title={
          <>
            Монтаж охранных систем <br /> и видеонаблюдения
          </>
        }
        body="Наряду с охраной объектов компания проектирует, осуществляет монтаж и обеспечивает сервис
          охранной сигнализации и установку камер видеонаблюдения как по периметру, так и внутри
          объекта"
      />

      <CardBgService price={price?.videosystem} loading={loading} image="/assets/service/videosystem.png" />

      <Stack alignItems="center" justifyContent="center" mt={{ xs: 7.5, sm: 13 }}>
        <Card sx={{ width: '100%', maxWidth: 680 }}>
          <CardContent
            sx={{
              padding: { xs: '24px', sm: '40px' },
              '&:last-child': {
                paddingBottom: { xs: '24px', sm: '40px' },
              },
            }}
          >
            <Typography
              variant="subtitle1"
              sx={{
                lineHeight: { xs: '128.571%', sm: '130%' },
              }}
            >
              В зависимости от особенностей объекта, пожеланий и финансовых ресурсов клиента наши
              специалисты за короткое время разработают и согласуют наиболее оптимальную схему
              технического укрепления и защиты любого объекта
            </Typography>
          </CardContent>
        </Card>
      </Stack>
    </Container>
  );
}

export default VideoSystemSection;
