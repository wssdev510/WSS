import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import { BoxBorderStyled } from '@/sections/bodyguard/price';
import CheckIcon from '@mui/icons-material/Check';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

const info = [
  'Предотвращение несанкционированного доступа',
  'Безопасность сотрудников и посетителей',
  'Защиту имущества, предотвращение, пресечение краж',
  'Оперативное реагирование при возникновении угроз и внештатных ситуаций',
  'Антитеррористическую безопасность, укрепление',
  'Патрулирование территории и контроль с помощью систем видеонаблюдения',
];

function ObjectSecuritySection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title="Охрана объектов"
        body="Охрана объекта включает в себя его оценку, разработку и реализацию эффективной системы
          безопасности с учетом специфики объекта и последующий контроль с соблюдением всех законов
          и нормативных актов"
      />

      <CardBgService price={price?.objectSecurity} loading={loading} image="/assets/service/objects-security.png" />

      <Stack
        alignItems="center"
        justifyContent="center"
        mb={{ xs: 1, sm: 0 }}
        mt={{ xs: 7, sm: 13 }}
      >
        <Stack sx={{ maxWidth: 680 }}>
          <Stack mx={{ xs: 3, sm: 0 }} mb={{ xs: 2.5, sm: 7.5 }} alignItems="center">
            <Typography
              variant="subtitle2"
              sx={{
                textAlign: { xs: 'left', sm: 'center' },
                maxWidth: 600,
                lineHeight: { xs: '128.571%', sm: '133.333%' },
              }}
            >
              В рамках оказания услуги мы обеспечиваем:
            </Typography>
          </Stack>

          <Stack spacing={2.5}>
            {info.map((item, key) => (
              <BoxBorderStyled key={key} sx={{ height: 140 }}>
                <Stack
                  direction="row"
                  spacing={{ xs: 2, sm: 3.5 }}
                  alignItems={{ xs: 'flex-start', sm: 'center' }}
                  sx={{ height: '100%' }}
                >
                  <CheckIcon sx={{ fontSize: { xs: 16, sm: 24 } }} />
                  <Typography variant="body1" sx={{ lineHeight: '125%' }}>
                    {item}
                  </Typography>
                </Stack>
              </BoxBorderStyled>
            ))}
          </Stack>
        </Stack>
      </Stack>
    </Container>
  );
}

export default ObjectSecuritySection;
