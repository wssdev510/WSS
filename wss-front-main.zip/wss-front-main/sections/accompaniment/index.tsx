import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import { BoxBorderStyled } from '@/sections/bodyguard/price';
import CheckIcon from '@mui/icons-material/Check';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

export const BgStyled = styled(Stack)<{ image?: string }>(({ theme, image }) => ({
  backgroundImage: `url('${image}')`,
  paddingTop: 60,
  paddingBottom: 60,
  borderRadius: '20px',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'center',
  height: '356px',
  [theme.breakpoints.down('sm')]: {
    height: '160px',
    borderRadius: '10px',
  },
}));

const info = [
  'Защиту от потенциальных угроз и конфликтных ситуаций во время посадки и высадки клиента, сопровождения до точки назначения, поездок и остановок',
  'Быстрое и профессиональное разрешение внештатных ситуаций, возникающих во время движения',
  'Разработку и выбор оптимального маршрута передвижения исходя из оперативной обстановки',
  'Взаимодействие с правоохранительными органами и другими службами для обеспечения дополнительной защиты в случае нарушения законности',
];

function AccompanimentSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title="Сопровождение"
        body="Сопровождение на автомобиле – это комплекс мероприятий, который гарантирует вашу
          безопасность во время передвижения"
      />

      <CardBgService
        price={price?.accompaniment}
        loading={loading}
        image="/assets/service/accompaniment.png"
      />

      <Stack
        alignItems="center"
        justifyContent="center"
        mb={{ xs: 1, sm: 0 }}
        mt={{ xs: 7, sm: 13 }}
      >
        <Stack sx={{ maxWidth: 680 }}>
          <Stack mx={{ xs: 3, sm: 0 }} mb={{ xs: 2.5, sm: 7.5 }} alignItems="center">
            <Typography
              variant="subtitle2"
              sx={{
                textAlign: { xs: 'left', sm: 'center' },
                maxWidth: 600,
                lineHeight: { xs: '128.571%', sm: '133.333%' },
              }}
            >
              Сопровождение осуществляется командой профессионалов на специально оборудованных
              автомобилях премиум класса, что позволяет обеспечить:
            </Typography>
          </Stack>

          <Stack spacing={2.5}>
            {info.map((item, key) => (
              <BoxBorderStyled key={key} sx={{ height: 140 }}>
                <Stack
                  direction="row"
                  spacing={{ xs: 2, sm: 3.5 }}
                  justifyContent={{ xs: 'flex-start', sm: 'center' }}
                  alignItems={{ xs: 'flex-start', sm: 'center' }}
                  sx={{ height: '100%' }}
                >
                  <CheckIcon sx={{ fontSize: { xs: 16, sm: 24 } }} />
                  <Typography variant="body1" sx={{ lineHeight: '125%' }}>
                    {item}
                  </Typography>
                </Stack>
              </BoxBorderStyled>
            ))}
          </Stack>
        </Stack>
      </Stack>
    </Container>
  );
}

export default AccompanimentSection;
