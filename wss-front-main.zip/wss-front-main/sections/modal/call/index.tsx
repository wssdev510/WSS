import * as yup from 'yup';
import React, { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { addDoc, collection, serverTimestamp } from '@firebase/firestore';
import Typography from '@mui/material/Typography';
import { db } from '@/firebase/init';
import { useMultiModal } from '@/context/multiModalContext';
import TextFieldMaskController from '@/components/hookForm/TextFieldController/mask';
import TextFieldController from '@/components/hookForm/TextFieldController';

type Props = {
  open: boolean;
  handleClose: () => void;
  isLogo?: boolean;
};

const validationSchema = yup.object().shape({
  full_name: yup.string().required(' is required'),
  comment: yup.string().required(' is required'),
  phone: yup
    .string()
    .required('Phone number is required')
    .matches(/^\+ 7 \([0-9]{3}\)-[0-9]{3}-[0-9]{2}-[0-9]{2}$/, 'Phone number is not valid'),
});

function CallModal({ open, isLogo, handleClose }: Props) {
  const [error, setError] = useState<Error | null>(null);
  const { dispatch } = useMultiModal();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const {
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onSubmit = async (data: { full_name: string; phone: string; comment: string }) => {
    const collectionRef = collection(db, 'call');

    try {
      await addDoc(collectionRef, {
        ...data,
        timestamp: serverTimestamp(),
      });

      reset({
        full_name: '',
        phone: '',
        comment: '',
      });

      dispatch({ type: 'CLOSE_MODAL', modalKey: 'call' });
    } catch (error: any) {
      console.error('Error adding document: ', error);
      setError(error);
    }
  };

  return (
    <Dialog
      fullScreen={isMobile}
      open={open}
      onClose={() => {
        reset();
        handleClose();
      }}
      maxWidth="md"
      fullWidth={true}
      sx={{
        '& .MuiPaper-root': {
          position: 'relative',
          borderRadius: { xs: 0, sm: '15px' },
        },
      }}
    >
      <form onSubmit={handleSubmit(onSubmit)}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ flexGrow: 1, height: '85px' }}
          mt={{ xs: 0, md: 3 }}
          ml={{ xs: 1, md: 5 }}
          mr={{ xs: 2, md: 5 }}
        >
          <Stack alignItems="center">
            {isLogo && (
              <Image src="/logo/logo.svg" width={72} height={72} alt="logo" onClick={handleClose} />
            )}
          </Stack>

          <Stack>
            <IconButton
              sx={{
                border: '1px solid rgba(234, 99, 3, 0.5)',
                width: { xs: 24, sm: 32, md: 48 },
                height: { xs: 24, sm: 32, md: 48 },
                '&:hover': {
                  border: '1px solid #EA6303',
                },
              }}
              color="inherit"
              onClick={handleClose}
            >
              <CloseIcon
                color="primary"
                sx={{ width: { xs: 12, sm: 16, md: 24 }, height: { xs: 12, sm: 16, md: 24 } }}
              />
            </IconButton>
          </Stack>
        </Stack>

        <Stack direction="row" justifyContent="space-between" mx={{ xs: 2, md: 3 }}>
          <DialogTitle
            sx={{
              marginTop: { xs: 3, sm: '-40px' },
              paddingTop: 0,
              flexGrow: 1,
              textAlign: 'center',
              fontSize: { xs: 24, sm: 32, md: 48 },
              fontWeight: 600,
              lineHeight: '116.667%',
            }}
          >
            Закажите звонок
          </DialogTitle>
        </Stack>

        <DialogContent sx={{ paddingX: { xs: 2, sm: 3 }, paddingTop: 0 }}>
          <DialogContentText
            color="primary"
            sx={{
              textAlign: { xs: 'center', md: 'start' },
              whiteSpace: { xs: 'wrap', md: 'nowrap' },
              marginLeft: { xs: 0, md: 6 },
              marginRight: { xs: 0, md: 6 },
              fontSize: { xs: 16, md: 18, lg: 20 },
            }}
          >
            Оставьте свои контактные данные
            <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> и мы перезвоним вам
            <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> в течение 30 минут
          </DialogContentText>

          <Stack mt={3} spacing={2} px={{ xs: 0, md: 10 }}>
            <TextFieldController
              label="ФИО"
              name="full_name"
              placeholder="Иванов Иван Иванович"
              control={control}
              errors={errors}
            />
            <TextFieldMaskController
              label="Номер телефона"
              name="phone"
              placeholder="+ 7 (999)-999-99-99"
              control={control}
              errors={errors}
            />
            <TextFieldController
              label="Комментарии"
              name="comment"
              placeholder="Здесь вы можете оставить свои пожелания"
              control={control}
              errors={errors}
              multiline
              rows={8}
            />
            {error && (
              <Typography variant="body2" color="error">
                {error.message}
              </Typography>
            )}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ paddingBottom: 5, justifyContent: 'center', gap: '32px' }}>
          <Button
            variant="outlined"
            color="secondary"
            type="submit"
            fullWidth={isMobile}
            sx={{
              height: { xs: 50, sm: 58 },
              fontSize: { xs: 16, sm: 24 },
              marginLeft: '20px',
              marginRight: '20px',
            }}
          >
            {isMobile ? 'Заказать звонок' : 'Отправить заявку'}
          </Button>
          {!isMobile && (
            <Button
              onClick={handleClose}
              sx={{
                textTransform: 'none',
                height: { xs: 50, sm: 58 },
                fontSize: { xs: 16, sm: 24 },
              }}
            >
              Отмена
            </Button>
          )}
        </DialogActions>
      </form>
    </Dialog>
  );
}

export default CallModal;
