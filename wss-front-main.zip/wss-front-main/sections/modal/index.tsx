import React from 'react';
import { useMultiModal } from '@/context/multiModalContext';
import MenuDialog from '@/sections/modal/menu';
import CallModal from '@/sections/modal/call';

function ModalSection() {
  const { state, dispatch } = useMultiModal();

  const handleClose = (modalKey: string) => {
    dispatch({ type: 'CLOSE_MODAL', modalKey });
  };

  return (
    <>
      <MenuDialog open={state['menu']?.isOpen ?? false} handleClose={() => handleClose('menu')} />
      <CallModal
        open={state['call']?.isOpen ?? false}
        isLogo={state['call']?.isLogo ?? false}
        handleClose={() => handleClose('call')}
      />
    </>
  );
}

export default ModalSection;
