import React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Stack from '@mui/material/Stack';
import Link from '@mui/material/Link';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import RouterLink from '@/components/routerLink';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import { Link as ScrollLink } from 'react-scroll/modules';
import { useMultiModal } from '@/context/multiModalContext';

type Props = {
  open: boolean;
  handleClose: () => void;
};

const ButtonStyled = styled(Button)(({ theme }) => ({
  padding: '5px 28px',
  borderRadius: '20px',
  fontSize: 16,
  [theme.breakpoints.down('sm')]: {
    height: 40,
  },
}));

function MenuDialog({ open, handleClose }: Props) {
  const { dispatch } = useMultiModal();

  const handleOpenCall = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'call', isLogo: true });
  };

  return (
    <Dialog
      fullScreen
      open={open}
      onClose={handleClose}
      sx={{
        '& .MuiPaper-root': {
          boxShadow: 'none',
        },
      }}
    >
      <AppBar
        color="transparent"
        position="static"
        sx={{ paddingLeft: '8px', paddingRight: '16px' }}
      >
        <Toolbar disableGutters>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ flexGrow: 1, height: '85px', boxShadow: 'none' }}
          >
            <Link
              sx={{ display: 'flex' }}
              underline="none"
              component={RouterLink}
              onClick={handleClose}
              href="/"
            >
              <Image src="/logo/logo.svg" width={72} height={72} alt="logo" />
            </Link>

            <Stack>
              <IconButton
                color="inherit"
                onClick={handleClose}
                sx={{ transform: 'rotate(90deg)', p: 0 }}
              >
                <Image src="/assets/icon/menu.svg" width={23} height={15} alt="menu" />
              </IconButton>
            </Stack>
          </Stack>
        </Toolbar>
      </AppBar>

      <Stack spacing={5} mt={2} justifyContent="center" alignItems="center">
        <Link
          underline="none"
          component={RouterLink}
          onClick={handleClose}
          href="/?section=services"
        >
          <Typography component="span" variant="body1">
            Услуги
          </Typography>
        </Link>
        <Link
          underline="none"
          component={RouterLink}
          onClick={handleClose}
          href="/?section=transport"
        >
          <Typography component="span" variant="body1">
            Транспорт
          </Typography>
        </Link>
        <Link underline="none" component={RouterLink} href="/gallery" onClick={handleClose}>
          <Typography component="span" variant="body1">
            Галерея
          </Typography>
        </Link>

        <ScrollLink offset={-130} to={'contact'} smooth={true} onClick={handleClose}>
          <Typography component="span" variant="body1">
            Контакты
          </Typography>
        </ScrollLink>
      </Stack>
      <Stack mt={5} mb={3} justifyContent="center" alignItems="center">
        <ButtonStyled onClick={handleOpenCall} variant="outlined" size="small" color="secondary">
          Заказать охрану
        </ButtonStyled>
      </Stack>
    </Dialog>
  );
}

export default MenuDialog;
