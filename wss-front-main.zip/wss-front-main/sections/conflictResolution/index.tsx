import React, { useEffect, useState } from 'react';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { BoxBorderStyled } from '@/sections/bodyguard/price';
import CheckIcon from '@mui/icons-material/Check';
import Box from '@mui/material/Box';
import TitleService from '@/components/tittleService';
import CardBgService from '@/components/cardBgService';
import { DocumentData } from '@firebase/firestore-types';
import { fetchDocAndSubCollection } from '@/firebase/api';

const info = [
  'Для обеспечения личной безопасности клиента',
  'В семейных спорах',
  'Деловых переговорах и бизнес встречах',
  'При разрешении конфликтов в судебном порядке и иных разногласиях позиций и интересов',
];

function ConflictResolutionSection() {
  const [loading, setLoading] = useState(true);
  const [price, setPrice] = useState<DocumentData | undefined>(undefined);

  useEffect(() => {
    fetchDocAndSubCollection()
      .then((res) => setPrice(res))
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <Container maxWidth="xl">
      <TitleService
        title="Решение конфликтов"
        body="Предоставление исчерпывающей юридической информации в рамках правового поля, которая
          необходима для конструктивного выхода из конфликтных ситуаций"
      />

      <CardBgService
        price={price?.conflictResolution}
        loading={loading}
        image="/assets/service/conflict-resolution.png"
      />

      <Stack alignItems="center" justifyContent="center" mt={{ xs: 7, sm: 13 }}>
        <Card sx={{ width: '100%', maxWidth: 920 }}>
          <CardContent
            sx={{
              padding: { xs: '24px', sm: '40px', md: '40px 85px 60px 85px' },
              '&:last-child': {
                paddingBottom: { xs: '24px', sm: '40px', md: '60px' },
              },
            }}
          >
            <Typography variant="subtitle1" sx={{ lineHeight: { xs: '128.571%', sm: '140%' } }}>
              Превентивное выявление возможных скрытых угроз <br /> по отношению к клиенту{' '}
              <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> и его
              собственности <br /> и предоставление конкретных рекомендаций.
              <br />
              <br />
              Профессиональное разрешение конфликтов может применяться <br /> в различных областях:
            </Typography>
          </CardContent>
        </Card>

        <Stack mt={{ xs: 3, sm: 7.5 }} spacing={2.5} sx={{ maxWidth: '680px' }}>
          {info.map((item, key) => (
            <BoxBorderStyled key={key} sx={{ height: 100 }}>
              <Stack
                direction="row"
                spacing={{ xs: 2, sm: 3.5 }}
                alignItems={{ xs: 'flex-start', sm: 'center' }}
                sx={{ height: '100%' }}
              >
                <CheckIcon sx={{ fontSize: { xs: 16, sm: 24 } }} />
                <Typography variant="body1" sx={{ lineHeight: '125%' }}>
                  {item}
                </Typography>
              </Stack>
            </BoxBorderStyled>
          ))}
        </Stack>
      </Stack>
    </Container>
  );
}

export default ConflictResolutionSection;
