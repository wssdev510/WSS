'use client';

import HeroSection from '@/sections/home/hero';
import ServicesSection from '@/sections/home/services';
import ApproachSection from '@/sections/home/approach';
import TransportSection from '@/sections/home/transport';
import GallerySection from '@/sections/home/gallery';

export default function Home() {


  return (
    <>
      <HeroSection />
      <ServicesSection />
      <ApproachSection />
      <TransportSection />
      <GallerySection />
    </>
  );
}
