'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import VideoSystemSection from '@/sections/videosystem';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <VideoSystemSection />
    </>
  );
}

export default Page;
