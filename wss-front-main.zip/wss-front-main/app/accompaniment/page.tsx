'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import AccompanimentSection from '@/sections/accompaniment';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <AccompanimentSection />
    </>
  );
}

export default Page;
