'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import AlbumSection from '@/sections/gallery/album';

function Page() {
  return (
    <>
      <BreadCrumbs title="К галерее" href="/gallery" />
      <AlbumSection />
    </>
  );
}

export default Page;
