'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import BodyguardPriceSection from '@/sections/bodyguard/price';
import OurEmployees from '@/sections/bodyguard/ourEmployees';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <BodyguardPriceSection />
      <OurEmployees />
    </>
  );
}

export default Page;
