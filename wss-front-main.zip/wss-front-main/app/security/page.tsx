'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import BodyguardSection from '@/sections/bodyguard/price';
import AdvantageSection from '@/sections/security/advantage';
import EmployeesSection from '@/sections/security/employees';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <BodyguardSection />
      <AdvantageSection />
      <EmployeesSection />
    </>
  );
}

export default Page;
