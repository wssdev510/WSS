'use client';

import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from '@/theme/theme';
import { MultiModalProvider } from '@/context/multiModalContext';
import Layout from '@/layouts';

function Children({ children }: { children: React.ReactNode }) {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <MultiModalProvider>
          <Layout>{children}</Layout>
        </MultiModalProvider>
      </ThemeProvider>
    </>
  );
}

export default Children;
