'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import PersonnelSelectionSection from '@/sections/personnelSelection';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <PersonnelSelectionSection />
    </>
  );
}

export default Page;
