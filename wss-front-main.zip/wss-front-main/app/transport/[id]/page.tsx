import ChildrenTransport from '@/app/transport/[id]/children';

function Page() {
  return <ChildrenTransport />;
}

export default Page;
