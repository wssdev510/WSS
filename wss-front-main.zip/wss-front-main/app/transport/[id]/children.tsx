'use client';

import React, { useEffect, useState } from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import HeroCarSection from '@/sections/transport/hero';
import GalleryCarSection from '@/sections/transport/gallery';
import { DocumentData } from '@firebase/firestore-types';
import { usePathname } from 'next/navigation';
import { fetchTransportCollection } from '@/firebase/api';

function ChildrenTransport() {
  const [transport, setTransport] = useState<DocumentData | undefined>(undefined);
  const [loading, setLoading] = useState(true);

  const pathname = usePathname();

  useEffect(() => {
    const id = pathname.split('/').pop();
    setLoading(true);

    fetchTransportCollection(id)
      .then((res) => setTransport(res))
      .finally(() => setLoading(false));
  }, [pathname]);

  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <HeroCarSection transport={transport} loading={loading} />
      {transport?.isGallery && <GalleryCarSection transport={transport} />}
    </>
  );
}

export default ChildrenTransport;
