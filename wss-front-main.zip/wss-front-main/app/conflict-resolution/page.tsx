'use client';

import React from 'react';
import BreadCrumbs from '@/components/breadСrumbs';
import ConflictResolutionSection from '../../sections/conflictResolution';

function Page() {
  return (
    <>
      <BreadCrumbs title="На главную" href="/" />
      <ConflictResolutionSection />
    </>
  );
}

export default Page;
