import React, { createContext, useReducer, useContext, ReactNode, Dispatch } from 'react';

interface ModalState {
  isOpen: boolean;
  isLogo?: boolean;
}

interface ModalsState {
  [key: string]: ModalState;
}

interface OpenModalAction {
  type: 'OPEN_MODAL';
  modalKey: string;
  isLogo?: boolean;
}

interface CloseModalAction {
  type: 'CLOSE_MODAL';
  modalKey: string;
}

type ModalAction = OpenModalAction | CloseModalAction;

const MultiModalContext = createContext<
  { state: ModalsState; dispatch: Dispatch<ModalAction> } | undefined
>(undefined);

const initialState: ModalsState = {};

function modalReducer(state: ModalsState, action: ModalAction): ModalsState {
  switch (action.type) {
    case 'OPEN_MODAL':
      return {
        ...state,
        [action.modalKey]: { isOpen: true, isLogo: Boolean(action.isLogo) },
      };
    case 'CLOSE_MODAL':
      return {
        ...state,
        [action.modalKey]: { isOpen: false },
      };
    default:
      throw new Error(`Unknown action type`);
  }
}

interface MultiModalProviderProps {
  children: ReactNode;
}

export function MultiModalProvider({ children }: MultiModalProviderProps) {
  const [state, dispatch] = useReducer(modalReducer, initialState);

  return (
    <MultiModalContext.Provider value={{ state, dispatch }}>{children}</MultiModalContext.Provider>
  );
}

export function useMultiModal() {
  const context = useContext(MultiModalContext);
  if (!context) {
    throw new Error('useMultiModal must be used within a MultiModalProvider');
  }
  return context;
}
