import { collection, doc, getDoc, getDocs } from '@firebase/firestore';
import { db } from '@/firebase/init';

interface GalleryItem {
  id: string;
  tag: string;
}
const fetchDocAndSubCollection = async () => {
  try {
    const docRef = doc(db, 'services', 'price');
    const docSnap = await getDoc(docRef);
    return docSnap.data();
  } catch (error) {
    console.error('Error fetching document:', error);
  }
};

const fetchTransportCollection = async (id: string | undefined) => {
  const transportRef = collection(db, 'transport');
  const dataSnapshot = await getDocs(transportRef);
  let dataList = dataSnapshot.docs.map((doc) => ({
    ...doc.data(),
  }));
  try {
    if (id) {
      return dataList.find((data) => data.id === id);
    }
    return undefined;
  } catch (error) {
    console.error('Error fetching document:', error);
  }
};

const fetchGalleryId = async (id: any) => {
  try {
    const docRef = doc(db, 'gallery', id);
    const docSnap = await getDoc(docRef);

    return docSnap.data();
  } catch (error) {
    console.error('Error fetching document:', error);
  }
};

const fetchGalleryCollection = async (value: string | undefined) => {
  try {
    const dataCollection = collection(db, 'gallery');
    const dataSnapshot = await getDocs(dataCollection);
    let dataList: GalleryItem[] = dataSnapshot.docs.map((doc) => ({
      id: doc.id,
      tag: doc.data().tag,
      ...doc.data(),
    }));

    if (value !== 'all') {
      return dataList.filter((data) => data.tag === value);
    }

    return dataList;
  } catch (error) {
    console.error('Error fetching data: ', error);
  }
};

const fetchTagsCollection = async () => {
  try {
    const tagsCollectionRef = collection(db, 'tags');
    const tagsSnapshot = await getDocs(tagsCollectionRef);
    return tagsSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
  } catch (error) {
    console.error('Error fetching tags:', error);
  }
};

export {
  fetchDocAndSubCollection,
  fetchTransportCollection,
  fetchGalleryId,
  fetchGalleryCollection,
  fetchTagsCollection,
};
