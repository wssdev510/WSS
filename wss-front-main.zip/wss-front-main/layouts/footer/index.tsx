import React from 'react';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Form from '@/layouts/footer/form';
import MailOutlinedIcon from '@mui/icons-material/MailOutlined';
import Link from '@mui/material/Link';
import SocialLink from '@/components/socialLink';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import { Element } from 'react-scroll';

const StackStyled = styled(Stack)(({ theme }) => ({
  padding: 40,
  maxWidth: '680px',
  borderRadius: '20px',
  background: '#191919',
  boxShadow:
    '4px 4px 8px 0px #1E1E1E inset, -4px -4px 8px 0px rgba(77, 77, 77, 0.25) inset, 10px 10px 20px 0px #1E1E1E, -10px -10px 20px 0px #121212',
  [theme.breakpoints.down('sm')]: {
    padding: 20,
    paddingBottom: 40,
  },
}));

function Footer() {
  return (
    <Element name="contact">
      <Container maxWidth="xl">
        <Box
          sx={{ position: 'relative', zIndex: 2 }}
          mt={{ xs: 15, sm: 40 }}
          mb={{ xs: 10, sm: 15 }}
        >
          <Grid container spacing={{ xs: 10, md: 4.5 }} justifyContent="center">
            <Grid item xs={12} sm={9} md={8} lg={6}>
              <Stack sx={{ maxWidth: { xs: 'auto', lg: '540px' } }}>
                <Typography variant="h2" sx={{ textAlign: { xs: 'center', sm: 'left' } }}>
                  Закажите звонок
                </Typography>
                <Typography
                  variant="subtitle2"
                  mt={2.5}
                  mb={4.5}
                  sx={{ textAlign: { xs: 'center', sm: 'left' }, lineHeight: 1.3 }}
                >
                  Оставьте свои контактные данные
                  <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> и мы
                  перезвоним <Box component="br" sx={{ display: { xs: 'none', sm: 'block' } }} />
                  вам
                  <Box component="br" sx={{ display: { xs: 'block', sm: 'none' } }} /> в течении 30
                  минут:
                </Typography>
                <Form />
              </Stack>
            </Grid>
            <Grid item xs={12} sm={9} md={8} lg={6}>
              <StackStyled alignItems={{ xs: 'center', md: 'stretch' }}>
                <Typography variant="h2" mb={{ xs: 2, md: 5 }}>
                  Контакты
                </Typography>
                <Typography
                  variant="subtitle2"
                  mb={2}
                  sx={{ fontSize: { xs: 18, sm: 18 }, textAlign: { xs: 'center', sm: 'left' } }}
                >
                  <b>Москва,</b> Новинский бул. 8
                </Typography>

                <Stack direction="row" alignItems="center" spacing={1} mb={{ xs: 2, md: 3.5 }}>
                  <MailOutlinedIcon />
                  <Link underline="none" href="mailto:worldsecgroup@gmail.com">
                    <Typography
                      component="span"
                      variant="subtitle1"
                      color="#EA6303"
                      fontSize={20}
                      sx={{ lineHeight: 1.25 }}
                    >
                      worldsecgroup@gmail.com
                    </Typography>
                  </Link>
                </Stack>

                <Stack
                  direction={{ xs: 'column', md: 'row' }}
                  alignItems={{ xs: 'center', md: 'flex-start' }}
                  justifyContent="space-between"
                  mr={{ xs: 0, lg: 2 }}
                >
                  <Stack>
                    <Link
                      sx={{ marginTop: { xs: 0, sm: 1 } }}
                      underline="none"
                      href="tel:+74951362362"
                    >
                      <Typography component="span" variant="h3" fontWeight={400}>
                        +7 495 136 23 62
                      </Typography>
                    </Link>
                    <Typography
                      mt={1}
                      mb={{ xs: 3, md: 0 }}
                      sx={{ textAlign: { xs: 'center', md: 'start' }, lineHeight: 1.25 }}
                      variant="body1"
                    >
                      Круглосуточно
                    </Typography>
                  </Stack>
                  <SocialLink />
                </Stack>
              </StackStyled>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </Element>
  );
}

export default Footer;
