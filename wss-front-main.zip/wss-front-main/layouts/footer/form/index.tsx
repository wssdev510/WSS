import * as yup from 'yup';
import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import { useForm, Controller } from 'react-hook-form';
import InputMask from 'react-input-mask';
import { yupResolver } from '@hookform/resolvers/yup';
import { styled } from '@mui/material/styles';
import { addDoc, collection, serverTimestamp } from '@firebase/firestore';
import { db } from '@/firebase/init';

const validationSchema = yup.object().shape({
  full_name: yup.string().required(' is required'),
  phone: yup
    .string()
    .required('Phone number is required')
    .matches(/^\+ 7 \([0-9]{3}\)-[0-9]{3}-[0-9]{2}-[0-9]{2}$/, 'Phone number is not valid'),
});

const TextFieldStyled = styled(TextField)(({ theme }) => ({
  borderRadius: '10px',
  background: '#191919',
  boxShadow: '12px 12px 24px 0px #1E1E1E inset, -12px -12px 24px 0px #262626 inset',

  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderWidth: 1,
      borderColor: 'transparent',
    },
    '&:hover fieldset': {
      borderWidth: 1,
      borderColor: '#EA6303',
    },
    '&.Mui-focused fieldset': {
      borderWidth: 1,
      borderColor: '#EA6303',
    },
    '&.Mui-error fieldset': {
      borderWidth: '1px',
    },
  },

  '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
    display: 'none',
  },

  [theme.breakpoints.down('md')]: {},
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  width: '100%',
  maxWidth: 310,

  [theme.breakpoints.down('sm')]: {
    maxWidth: 240,
    height: 50,
    fontSize: 16,
  },
}));

function Form() {
  const [error, setError] = useState<Error | null>(null);

  const {
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  const onSubmit = async (data: { full_name: string; phone: string }) => {
    const collectionRef = collection(db, 'call');

    try {
      await addDoc(collectionRef, {
        ...data,
        timestamp: serverTimestamp(),
      });
      reset({
        full_name: '',
        phone: '',
      });
    } catch (error: any) {
      console.error('Error adding document: ', error);
      setError(error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={2} mb={5}>
        <Stack>
          <Typography mb={1} variant="subtitle2" color="#878787">
            ФИО
          </Typography>
          <Controller
            name="full_name"
            control={control}
            render={({ field }) => (
              <TextFieldStyled
                {...field}
                placeholder="Введите ФИО"
                variant="outlined"
                fullWidth
                error={Boolean(errors.full_name)}
              />
            )}
          />
        </Stack>

        <Stack>
          <Typography mb={1} variant="subtitle2" color="#878787">
            Номер телефона
          </Typography>
          <Controller
            name="phone"
            control={control}
            render={({ field }) => (
              <InputMask
                mask="+ 7 (999)-999-99-99"
                value={field.value}
                onChange={field.onChange}
                onBlur={field.onBlur}
              >
                <TextFieldStyled
                  {...field}
                  placeholder="+ 7 (999)-999-99-99"
                  variant="outlined"
                  fullWidth
                  error={Boolean(errors.phone)}
                />
              </InputMask>
            )}
          />
        </Stack>

        {error && (
          <Typography variant="body2" color="error">
            {error.message}
          </Typography>
        )}
      </Stack>

      <Stack alignItems={{ xs: 'center', md: 'flex-start' }}>
        <ButtonStyled type="submit" variant="outlined" color="secondary">
          Заказать звонок
        </ButtonStyled>
      </Stack>
    </form>
  );
}

export default Form;
