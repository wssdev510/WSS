import React from 'react';
import Header from '@/layouts/header';
import Footer from '@/layouts/footer';
import ModalSection from '@/sections/modal';

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      <>{children}</>
      <Footer />
      <ModalSection />
    </>
  );
}

export default Layout;
