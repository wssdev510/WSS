import React from 'react';
import Link from '@mui/material/Link';
import { Link as ScrollLink } from 'react-scroll/modules';
import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';

const LinkStyled = styled(Link)<{ component?: React.ElementType; active?: string }>(
  ({ theme, active }) => ({
    fontSize: 18,
    fontWeight: 500,
    lineHeight: '133.333%',
    fontStyle: 'normal',
    color: active === 'true' ? '#EA6303' : '#E9E9E9',
    backgroundColor: 'transparent',
    transition: 'all .2s ease-in',
    '&:hover': {
      color: '#EA6303',
      textShadow: '0px 0px 10px #EA6303',
    },

    [theme.breakpoints.down('lg')]: {
      fontSize: 16,
    },
  })
);

const ScrollLinkWithDefaults = ({ to = '#', ...props }) => <ScrollLink {...props} to={to} />;

const ScrollLinkStyled = styled(ScrollLinkWithDefaults)(({ theme }) => ({
  cursor: 'pointer',
  color: '#E9E9E9',
  fontSize: 18,
  fontWeight: 500,
  lineHeight: '133.333%',
  fontStyle: 'normal',
  backgroundColor: 'transparent',
  transition: 'all .2s ease-in',
  '&:hover': {
    color: '#EA6303',
    textShadow: '0px 0px 10px #EA6303',
  },

  [theme.breakpoints.down('lg')]: {
    fontSize: 16,
  },
}));

const AppBarStyled = styled(AppBar)(({ theme }) => ({
  top: '30px',
  left: '50%',
  right: 'auto',
  height: '80px',
  transform: 'translate(-50%, 0)',
  maxWidth: '1400px',
  paddingLeft: '40px',
  paddingRight: '40px',
  backgroundColor: '#181818',
  borderRadius: '15px',
  color: '#000',
  boxShadow: '12px 12px 24px 0px #1E1E1E, -12px -12px 24px 0px #262626',

  [theme.breakpoints.down('md')]: {
    top: 0,
    height: '85px',
    borderRadius: 0,
    boxShadow: 'none',
  },

  '@media (max-width: 1000px)': {
    paddingLeft: '8px',
    paddingRight: '16px',
  },
}));

const ButtonStyled = styled(Button)(({ theme }) => ({
  padding: '5px 28px',
  borderRadius: '20px',
  fontSize: 16,

  [theme.breakpoints.down('sm')]: {
    fontSize: 14,
  },
  [theme.breakpoints.down('lg')]: {
    padding: '5px 20px',
  },
}));

export { LinkStyled, ScrollLinkStyled, AppBarStyled, ButtonStyled };
