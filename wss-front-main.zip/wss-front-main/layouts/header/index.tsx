import React, { useEffect } from 'react';
import Toolbar from '@mui/material/Toolbar';
import Image from 'next/image';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Link from '@mui/material/Link';
import { scroller } from 'react-scroll';
import RouterLink from '@/components/routerLink';

import { usePathname, useSearchParams } from 'next/navigation';
import { AppBarStyled, LinkStyled, ScrollLinkStyled, ButtonStyled } from '@/layouts/header/styles';
import { useMultiModal } from '@/context/multiModalContext';

const menu = [
  { href: '/?section=services', title: 'Услуги', to: 'services', isScroll: true },
  { href: '/?section=transport', title: 'Транспорт', to: 'transport', isScroll: true },
  { href: '/gallery', title: 'Галерея', to: '', isScroll: false },
  { href: '/', title: 'Контакты', to: 'contact', isScroll: true },
];

function Header() {
  const { dispatch } = useMultiModal();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const search = searchParams.get('section');

  const handleClickOpen = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'menu' });
  };
  const handleClickCallOpen = () => {
    dispatch({ type: 'OPEN_MODAL', modalKey: 'call' });
  };

  useEffect(() => {
    const newUrl = window.location.pathname;

    if (search) {
      scroller.scrollTo(search, {
        duration: 800,
        delay: 0,
        smooth: 'easeInOutQuart',
        offset: -130,
      });

      window.history.replaceState({}, '', newUrl);
    }
  }, [search]);

  return (
    <AppBarStyled position="fixed" color="transparent">
      <Toolbar disableGutters sx={{ height: '100%' }}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ flexGrow: 1 }}
        >
          <Stack sx={{ width: 110 }}>
            <Link
              sx={{
                display: 'flex',
                width: 72,
              }}
              underline="none"
              component={RouterLink}
              href="/"
            >
              <Image src="/logo/logo.svg" width={72} height={72} alt="logo" />
            </Link>
          </Stack>

          <Stack
            direction="row"
            sx={{ display: { xs: 'none', md: 'flex' } }}
            spacing={{ xs: 4, lg: 10 }}
          >
            {menu.map((item, key) => (
              <React.Fragment key={key}>
                {(item.isScroll && pathname === '/') || item.to === 'contact' ? (
                  <ScrollLinkStyled offset={-130} to={item.to} smooth={true}>
                    {item.title}
                  </ScrollLinkStyled>
                ) : (
                  <LinkStyled
                    underline="none"
                    component={RouterLink}
                    href={item.href}
                    active={pathname === item.href ? 'true' : 'false'}
                  >
                    {item.title}
                  </LinkStyled>
                )}
              </React.Fragment>
            ))}
          </Stack>

          <Stack
            direction="row"
            alignItems="center"
            spacing={{ xs: 2, lg: 2.75 }}
            sx={{ display: { xs: 'none', md: 'flex' } }}
          >
            <Link underline="none" href="tel:+74951362362">
              <Typography component="span" variant="body2" color="#B7B7B7">
                +7 495 136 23 62
              </Typography>
            </Link>
            <ButtonStyled
              onClick={handleClickCallOpen}
              variant="outlined"
              size="small"
              color="secondary"
            >
              Заказать охрану
            </ButtonStyled>
          </Stack>

          <Stack sx={{ display: { xs: 'flex', md: 'none' } }}>
            <IconButton color="inherit" onClick={handleClickOpen} sx={{ p: 0 }}>
              <Image src="/assets/icon/menu.svg" width={23} height={15} alt="menu" />
            </IconButton>
          </Stack>
        </Stack>
      </Toolbar>
    </AppBarStyled>
  );
}

export default Header;
