import { forwardRef, AnchorHTMLAttributes } from 'react';
import Link from 'next/link';

interface RouterLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  scroll?: boolean;
}

// ----------------------------------------------------------------------

// eslint-disable-next-line react/display-name
const RouterLink = forwardRef<HTMLAnchorElement, RouterLinkProps>(({ ...other }, ref) => (
  <Link ref={ref} {...other} />
));

export default RouterLink;
