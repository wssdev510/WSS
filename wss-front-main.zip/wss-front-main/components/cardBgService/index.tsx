import React from 'react';
import { BgStyled } from '@/sections/accompaniment';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import ServicePrice from '@/components/servicePrice';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Skeleton from '@mui/material/Skeleton';

function CardBgService({ price, loading, image }: { price: any; loading: boolean; image: string }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Box mt={{ xs: 4, sm: 7.5 }}>
      <BgStyled image={image} mb={{ xs: 3, sm: 0 }}>
        {isMobile && (
          <Stack sx={{ height: '100%', width: '100%' }} alignItems="center" justifyContent="center">
            <Typography
              variant="h2"
              fontWeight={700}
              color="secondary"
              sx={{ fontSize: '16px', display: { xs: 'block', sm: 'none' } }}
            >
              {loading ? <Skeleton variant="text" width={120} /> : price}
            </Typography>
          </Stack>
        )}

        {!isMobile && (
          <Stack
            alignItems="center"
            justifyContent="center"
            sx={{ display: { xs: 'none', sm: 'flex' }, height: '100%' }}
          >
            <ServicePrice price={price} loading={loading} />
          </Stack>
        )}
      </BgStyled>

      {isMobile && <ServicePrice price={price} loading={loading} />}
    </Box>
  );
}

export default CardBgService;
