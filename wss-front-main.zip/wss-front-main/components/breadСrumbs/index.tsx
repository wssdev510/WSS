import React from 'react';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import RouterLink from '@/components/routerLink';
import Link from '@mui/material/Link';

function BreadCrumbs({ title, href }: { title: string; href: string }) {
  return (
    <Container maxWidth="xl">
      <Link underline="none" component={RouterLink} href={href}>
        <Stack mt={{ xs: 13, sm: 28 }} direction="row" alignItems="center" spacing={1}>
          <ArrowBackIcon color="secondary" />
          <Typography variant="subtitle1" color="secondary">
            {title}
          </Typography>
        </Stack>
      </Link>
    </Container>
  );
}

export default BreadCrumbs;
