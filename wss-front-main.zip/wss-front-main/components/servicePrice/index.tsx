import React, { useState } from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import SocialLink from '@/components/socialLink';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import Skeleton from '@mui/material/Skeleton';
import CallModal from '@/sections/modal/call';

export const ButtonStyled = styled(Button)(({ theme }) => ({
  padding: '5px 56px',
  fontSize: 24,
  height: 58,
  [theme.breakpoints.down('sm')]: {
    fontSize: 16,
    height: 50,
  },
}));

function ServicePrice({ loading = true, price }: { loading?: boolean; price?: any }) {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Stack
      alignItems="center"
      justifyContent="center"
      spacing={{ xs: 2.5, sm: 3.75 }}
      sx={{ height: '100%' }}
    >
      <ButtonStyled variant="outlined" color="secondary" onClick={handleClickOpen}>
        Заказать
      </ButtonStyled>

      <SocialLink />
      <Typography
        variant="h2"
        fontWeight={700}
        color="secondary"
        sx={{ display: { xs: 'none', sm: 'block' } }}
      >
        {loading ? <Skeleton variant="text" width={300} /> : price}
      </Typography>

      <CallModal open={open} handleClose={handleClose} />
    </Stack>
  );
}

export default ServicePrice;
