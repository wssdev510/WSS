import React from 'react';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';

function TitleService({ title, body }: { title: any; body: any }) {
  return (
    <Box mt={{ xs: 2.5, sm: 7 }}>
      <Typography variant="h1" sx={{ textAlign: 'center' }}>
        {title}
      </Typography>
      <Stack
        mt={{ xs: 2.5, sm: 5 }}
        alignItems="center"
        justifyContent="center"
        mx={{ xs: 2.5, sm: 0 }}
      >
        <Typography
          variant="subtitle1"
          sx={{
            textAlign: { xs: 'left', sm: 'center' },
            maxWidth: 750,
            lineHeight: { xs: '128.571%', sm: '140%' },
          }}
        >
          {body}
        </Typography>
      </Stack>
    </Box>
  );
}

export default TitleService;
