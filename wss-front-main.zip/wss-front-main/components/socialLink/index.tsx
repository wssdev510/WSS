import React from 'react';
import IconButton from '@mui/material/IconButton';
import TelegramIcon from '@mui/icons-material/Telegram';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';

const IconButtonStyled = styled(IconButton)<{
  component?: React.ElementType;
  target?: any;
  href: string;
}>(({ theme }) => ({
  width: 58,
  height: 58,
  backgroundColor: '#181818',
  transition: 'background-color 0.3s ease',
  border: '1px solid rgba(234, 99, 3, 0.5)',
  '&:hover': {
    border: '1px solid #EA6303',
    backgroundColor: '#181818',
    boxShadow: '6px 6px 12px 0px #1E1E1E, -6px -6px 12px 0px #262626, 0px 0px 10px 0px #EA6303',
  },
  '&:active': {
    backgroundColor: '#EA6303',
  },
  [theme.breakpoints.down('sm')]: {
    width: 40,
    height: 40,
  },
}));

function SocialLink() {
  return (
    <Stack direction="row" spacing={{ xs: 2, sm: 3 }}>
      <IconButtonStyled component="a" target="_blank" href="https://t.me/worldsecuritygroup">
        <TelegramIcon color="primary" sx={{ fontSize: { xs: 16, sm: 24 } }} />
      </IconButtonStyled>
      <IconButtonStyled component="a" target="_blank" href="https://wa.me/message/XOVOEDUMV7E5F1">
        <WhatsAppIcon color="primary" sx={{ fontSize: { xs: 16, sm: 24 } }} />
      </IconButtonStyled>
    </Stack>
  );
}

export default SocialLink;
