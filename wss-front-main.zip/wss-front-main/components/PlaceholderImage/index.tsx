import { useCallback, useState } from 'react';
import Image from 'next/image';

interface MyImageProps {
  src: string;
  alt: string;
  [key: string]: any;
}

const PlaceholderImage = ({ src, alt, ...props }: MyImageProps) => {
  const [imageSrc, setImageSrc] = useState(src);

  const handleImageError = useCallback((e: any) => {
    if (e.target.src !== '/assets/icon/camera.svg') {
      e.target.style.position = 'relative';
      e.target.style.width = '24px';
      e.target.style.height = '24px';
      setImageSrc('/assets/icon/camera.svg');
    }
  }, []);

  return <Image src={imageSrc} alt={alt} onError={handleImageError} {...props} />;
};

export default PlaceholderImage;
