import React from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { Controller } from 'react-hook-form';
import TextFieldStyled from '@/components/hookForm/TextFieldController/styles';
import InputMask from 'react-input-mask';

interface MaskController {
  label?: string;
  name: string;
  placeholder?: string;
  control: any;
  errors: any;
}

function TextFieldMaskController({ label, name, placeholder, control, errors }: MaskController) {
  return (
    <Stack>
      <Typography mb={1} variant="subtitle2" color="#878787">
        {label}
      </Typography>
      <Controller
        name={name}
        control={control}
        render={({ field }) => (
          <InputMask
            mask="+ 7 (999)-999-99-99"
            value={field.value}
            onChange={field.onChange}
            onBlur={field.onBlur}
          >
            <TextFieldStyled
              {...field}
              placeholder={placeholder}
              variant="outlined"
              fullWidth
              error={Boolean(errors.full_name)}
            />
          </InputMask>
        )}
      />
    </Stack>
  );
}

export default TextFieldMaskController;
