import { styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';

const TextFieldStyled = styled(TextField)(({ theme }) => ({
  borderRadius: '10px',
  background: '#191919',
  boxShadow: '12px 12px 24px 0px #1E1E1E inset, -12px -12px 24px 0px #262626 inset',

  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderWidth: 1,
      borderColor: 'transparent',
    },
    '&:hover fieldset': {
      borderWidth: 1,
      borderColor: '#EA6303',
    },
    '&.Mui-focused fieldset': {
      borderWidth: 1,
      borderColor: '#EA6303',
    },
    '&.Mui-error fieldset': {
      borderWidth: '1px',
    },
  },

  '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
    display: 'none',
  },

  [theme.breakpoints.down('md')]: {},
}));

export default TextFieldStyled;
