import React from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { Controller } from 'react-hook-form';
import TextFieldStyled from '@/components/hookForm/TextFieldController/styles';

interface FieldController {
  label?: string;
  name: string;
  placeholder?: string;
  control: any;
  errors: any;
  multiline?: boolean;
  rows?: number;
}

function TextFieldController({
  label,
  name,
  placeholder,
  control,
  errors,
  multiline = false,
  rows = 1,
}: FieldController) {
  return (
    <Stack>
      <Typography mb={1} variant="subtitle2" color="#878787">
        {label}
      </Typography>
      <Controller
        name={name}
        control={control}
        render={({ field }) => (
          <TextFieldStyled
            {...field}
            placeholder={placeholder}
            variant="outlined"
            fullWidth
            multiline={multiline}
            rows={rows}
            error={Boolean(errors[name])}
          />
        )}
      />
    </Stack>
  );
}

export default TextFieldController;
